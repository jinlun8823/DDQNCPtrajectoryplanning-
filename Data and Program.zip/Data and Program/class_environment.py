import numpy as np

def turn_right(vx,vy,delta_xita=(0.3/36)*2*np.pi):
    if vx>=0 and vy>=0:
        xita=np.arctan(vy/(vx+0.00000001))
        vx2=((vx**2+vy**2)**(1/2))*np.cos(xita-delta_xita)
        vy2=((vx**2+vy**2)**(1/2))*np.sin(xita-delta_xita)
    if vx<0 and vy>=0:
        xita=np.arctan(vy/(-vx-0.00000001))
        vx2=-((vx**2+vy**2)**(1/2))*np.cos(xita+delta_xita)
        vy2=((vx**2+vy**2)**(1/2))*np.sin(xita+delta_xita)
    if vx<0 and vy<0:
        xita=np.arctan(-vy/(-vx-0.00000001))
        vx2=-((vx**2+vy**2)**(1/2))*np.cos(xita-delta_xita)
        vy2=-((vx**2+vy**2)**(1/2))*np.sin(xita-delta_xita)
    if vx>=0 and vy<0:
        xita=np.arctan(-vy/(vx+0.00000001))
        vx2=((vx**2+vy**2)**(1/2))*np.cos(xita+delta_xita)
        vy2=-((vx**2+vy**2)**(1/2))*np.sin(xita+delta_xita)
    return vx2,vy2

def turn_left(vx,vy,delta_xita=(0.3/36)*2*np.pi):
    if vx>=0 and vy>=0:
        xita=np.arctan(vy/(vx+0.0000000001))
        vx2=((vx**2+vy**2)**(1/2))*np.cos(xita+delta_xita)
        vy2=((vx**2+vy**2)**(1/2))*np.sin(xita+delta_xita)
    if vx<0 and vy>=0:
        xita=np.arctan(vy/(-vx+0.00000001))
        vx2=-((vx**2+vy**2)**(1/2))*np.cos(xita-delta_xita)
        vy2=((vx**2+vy**2)**(1/2))*np.sin(xita-delta_xita)
    if vx<0 and vy<0:
        xita=np.arctan(-vy/(-vx+0.0000000001))
        vx2=-((vx**2+vy**2)**(1/2))*np.cos(xita+delta_xita)
        vy2=-((vx**2+vy**2)**(1/2))*np.sin(xita+delta_xita)
    if vx>=0 and vy<0:
        xita=np.arctan(-vy/(vx+0.0000000001))
        vx2=((vx**2+vy**2)**(1/2))*np.cos(xita-delta_xita)
        vy2=-((vx**2+vy**2)**(1/2))*np.sin(xita-delta_xita)
    return vx2,vy2

class Environment:#####环境的强化学习建模
    def __init__(self,f1origin,f2origin,f1destination,f2destination,f1s,f2s):#######环境参数,后续可加云
        self.f1origin=f1origin
        self.f2origin=f2origin
        self.f1s=f1s
        self.f2s=f2s
        self.f1destination=f1destination
        self.f2destination=f2destination
    def reward(self,fuel_reward,safty_reward,distance_reward):#############奖励惩罚判定
        onestepreward=fuel_reward+safty_reward+distance_reward
        return onestepreward
    def s1tos2(self,x,y,z,vx,vy,vz,tr,tl,cl,dec,straight,
               ch_acc,ch_tr,ch_tl,ch_cl,ch_dec,ch_straight):############基于所选决策的状态转移，确定性状态转移方程
        s2x=x+(vx/3.6)/1000
        s2y=y+(vy/3.6)/1000
        s2z=z+vz
        s2vx=vx
        s2vy=vy
        s2vz=vz
        if ch_tr==1:
            s2vx,s2vy= turn_right(vx,vy,delta_xita=(0.3/36)*2*np.pi)
        if ch_tl==1:
            s2vx,s2vy= turn_left(vx,vy,delta_xita=(0.3/36)*2*np.pi)
        if ch_dec==1:
            s2vz=-0.0182439
        else:
            s2vz=0
        if ch_cl==1:
            s2vz=+0.0142439
        else:
            s2vz=0
        if ch_acc==1:
            if vx>=0 and vy>=0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=((vx**2+vy**2)**(1/2)+5)*np.cos(xita)
                s2vy=((vx**2+vy**2)**(1/2)+5)*np.sin(xita)
            if vx<0 and vy>=0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=-((vx**2+vy**2)**(1/2)+5)*np.cos(xita)
                s2vy=((vx**2+vy**2)**(1/2)+5)*np.sin(xita)
            if vx<0 and vy<0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=-((vx**2+vy**2)**(1/2)+5)*np.cos(xita)
                s2vy=-((vx**2+vy**2)**(1/2)+5)*np.sin(xita)
            if vx>=0 and vy<0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=((vx**2+vy**2)**(1/2)+5)*np.cos(xita)
                s2vy=-((vx**2+vy**2)**(1/2)+5)*np.sin(xita)
                
        if ch_acc==-1:
            if vx>=0 and vy>=0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=((vx**2+vy**2)**(1/2)-5)*np.cos(xita)
                s2vy=((vx**2+vy**2)**(1/2)-5)*np.sin(xita)
            if vx<0 and vy>=0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=-((vx**2+vy**2)**(1/2)-5)*np.cos(xita)
                s2vy=((vx**2+vy**2)**(1/2)-5)*np.sin(xita)
            if vx<0 and vy<0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=-((vx**2+vy**2)**(1/2)-5)*np.cos(xita)
                s2vy=-((vx**2+vy**2)**(1/2)-5)*np.sin(xita)
            if vx>=0 and vy<0:
                xita=np.arctan(vy/(vx+0.00000001))
                s2vx=((vx**2+vy**2)**(1/2)-5)*np.cos(xita)
                s2vy=-((vx**2+vy**2)**(1/2)-5)*np.sin(xita)

        s2tr=ch_tr
        s2tl=ch_tl
        s2cl=ch_cl
        s2dec=ch_dec
        s2straight=ch_straight
        # print(s2x,s2y,s2z,s2vx,s2vy,s2vz,s2tr,s2tl,s2cl,s2dec,s2straight)
        return [s2x,s2y,s2z,s2vx,s2vy,s2vz,s2tr,s2tl,s2cl,s2dec,s2straight]
    def update_f1s(self,f1s2):#########之所以更新f1和更新f2分开是有原因的
        self.f1s=f1s2
    def update_f2s(self,f2s2):
        self.f2s=f2s2
    def resetenv(self):#########################结束一轮迭代
        self.f1s=self.f1origin
        self.f2s=self.f2origin


#####生成实例测试
env=Environment([0,0,9.2,0,600,0,0,0,0,0,1],[0,100,9.5,600,0,0,0,0,0,0,1],[100,100,9.5],[100,0,9.2],[0,0,9.2,0,600,0,0,0,0,0,1],[0,100,9.5,600,0,0,0,0,0,0,1])
# a=env.f1origin
# reward=env.reward(3,4,5)
# #转弯测试#
# ##############f1右转弯
# env.resetenv()
# import matplotlib.pyplot as plt
# for i in range(200):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=1, ch_tl=0, ch_cl=0, ch_dec=0, ch_straight=0)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# plt.show()

# ##############f1左转弯
# env.resetenv()
# import matplotlib.pyplot as plt
# for i in range(200):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=0, ch_tl=1, ch_cl=0, ch_dec=0, ch_straight=0)
#     # print(env.f1s)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# plt.show()

#####爬升测试#
# env.resetenv()
# import matplotlib.pyplot as plt
# fig = plt.figure()

# for i in range(200):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=0, ch_tl=0, ch_cl=1, ch_dec=0, ch_straight=0)
#     env.update_f1s(f1s2)
#     print(f1s2)
#     plt.scatter(f1s2[1],f1s2[2])
# plt.show()
# #####下降测试#
# env.resetenv()
# import matplotlib.pyplot as plt
# fig = plt.figure()

# for i in range(200):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=0, ch_tl=0, ch_cl=0, ch_dec=1, ch_straight=0)
#     env.update_f1s(f1s2)
#     print(f1s2)
#     plt.scatter(f1s2[1],f1s2[2])
# plt.show()

# ####加速测试#
# env.resetenv()
# import matplotlib.pyplot as plt
# for i in range(20):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=1, ch_tr=0, ch_tl=0, ch_cl=0, ch_dec=0, ch_straight=1)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# plt.show()
# ####减速测试#
# env.resetenv()
# import matplotlib.pyplot as plt
# for i in range(20):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=-1, ch_tr=0, ch_tl=0, ch_cl=0, ch_dec=0, ch_straight=1)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# plt.show()
# ##########随便飞测试
# env.resetenv()

# import matplotlib.pyplot as plt
# for i in range(80):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=1, ch_tl=0, ch_cl=0, ch_dec=0, ch_straight=0)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# for i in range(100):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=0, ch_tl=1, ch_cl=0, ch_dec=0, ch_straight=0)
#     # print(env.f1s)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# for i in range(80):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=1, ch_tr=0, ch_tl=0, ch_cl=0, ch_dec=0, ch_straight=1)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# for i in range(600):
#     f1s2=env.s1tos2(x=env.f1s[0], y=env.f1s[1], z=env.f1s[2],vx=env.f1s[3], vy=env.f1s[4], vz=env.f1s[5],
#                   tr=env.f1s[6], tl=env.f1s[7], cl=env.f1s[8], dec=env.f1s[9], straight=env.f1s[10],
#                   ch_acc=0, ch_tr=0, ch_tl=1, ch_cl=0, ch_dec=0, ch_straight=0)
#     # print(env.f1s)
#     env.update_f1s(f1s2)
#     plt.scatter(f1s2[0],f1s2[1])
# plt.show()