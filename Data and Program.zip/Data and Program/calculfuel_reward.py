from fuelcalculation import atpara,CtoT,D,Thrforcr,FUELforcr,angle
from fuelcalculation import Thrforclimb,FUELforclimb,Thrfordecend,FUELfordecend


mref=60;S=124.65;
cf1=0.6864;cf2=952.85;cf3=10.592;cf4=59399;cfcr=0.9342;
cd0cr=0.023738;cd2cr=0.037669;
vclimb=1500;vdecend=3000;#####单位ft/min

def f1fuelcal(f1s1z,f1vscalar,f1s1climbing,f1s1decenting,f1s1straghting):#######算油耗的
    f1s1z=f1s1z*1000
    atpara1=atpara(f1s1z,0)
    if f1s1climbing==1:
        tas1=CtoT(f1vscalar,vclimb,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(f1vscalar,vclimb)
        thr1=Thrforclimb(Df,mref,xita)
        fuel1=-1*FUELforclimb(cf1,cf2,tas1,thr1)
    elif f1s1decenting==1:
        tas1=CtoT(f1vscalar,vdecend,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(f1vscalar,vdecend)
        thr1=Thrfordecend(Df,mref,xita)
        fuel1=-1*FUELfordecend(cf1,cf2,cf3,cf4,f1s1z,tas1,thr1)
    else:
        tas1=CtoT(f1vscalar,0,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        thr1=Thrforcr(Df)
        fuel1=FUELforcr(cf1,cf2,cfcr,tas1,thr1)
        fuel1=-1*fuel1
    return fuel1

def f2fuelcal(f2s1z,f2vscalar,f2s1climbing,f2s1decenting,f2s1straghting):
    f2s1z=f2s1z*1000
    atpara2=atpara(f2s1z,0)
    if f2s1climbing==1:
        tas2=CtoT(f2vscalar,vdecend,atpara2)
        Df=D(mref,S,tas2,cd0cr,cd2cr,atpara2[2])
        xita=angle(f2vscalar,vclimb)
        thr2=Thrforclimb(Df,mref,xita)
        fuel2=-1*FUELforclimb(cf1,cf2,tas2,thr2)
    elif f2s1decenting==1:
        tas2=CtoT(f2vscalar,vdecend,atpara2)
        Df=D(mref,S,tas2,cd0cr,cd2cr,atpara2[2])
        xita=angle(f2vscalar,vdecend)
        thr2=Thrfordecend(Df,mref,xita)
        fuel2=-1*FUELfordecend(cf1,cf2,cf3,cf4,f2s1z,tas2,thr2)
    else:
        tas2=CtoT(f2vscalar,0,atpara2)
        Df=D(mref,S,tas2,cd0cr,cd2cr,atpara2[2])
        thr2=Thrforcr(Df)
        fuel2=FUELforcr(cf1,cf2,cfcr,tas2,thr2)
        fuel2=-1*fuel2
    return fuel2
    
# #test#数据格式(高度(m),速度(km/h),是否爬升0-1变量，是否下降0-1变量，是否平飞0-1变量)
f_reward1=f1fuelcal(9.2,600,0,0,1)
f_reward2=f2fuelcal(9.451,666,0,1,0)
f_reward3=f1fuelcal(9.451,666,1,0,0)
# f_reward=f_reward1+f_reward2
# #test#
    
    
    
    