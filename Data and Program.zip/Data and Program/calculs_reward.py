
def situationawarereward(f1s1x,f1s1y,f1s1z,f2s1x,f2s1y,f2s1z):####算安全态势的奖励的(单位(km))
    d=((f1s1x-f2s1x)**2+(f1s1y-f2s1y)**2+(f1s1z-f2s1z)**2)**(1/2)
    if d<=13 and f1s1z-f2s1z<=0.25:
        safty_reward=-30
    else:
        safty_reward=0
    return safty_reward
######test#
# s_reward=situationawarereward(0,10,9.2,0,23.1,9.2)