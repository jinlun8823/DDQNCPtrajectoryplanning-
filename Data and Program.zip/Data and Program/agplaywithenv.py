from class_agent import agent
from class_environment import env
import numpy as np
from calculd_reward import f1_distodesreward,f2_distodesreward
from calculfuel_reward import f1fuelcal,f2fuelcal
from calculs_reward import situationawarereward
from replayer import DDQNreplayer5000
from keras.models import load_model

agent.evanet=load_model('evanet.h5')
agent.targetnet=load_model('targetnet.h5')

def agentplaywithenv(env,agent):
    env.resetenv()
    totalreward=0
    for i in range(0,2500):
        # print(i)
        f1s1=env.f1s
        f2s1=env.f2s
        f1origin=env.f1origin;f1destination=env.f1destination
        f2origin=env.f2origin;f2destination=env.f2destination
        ###################################################################################
        s1_to_memo=[f1s1[0],f1s1[1],f1s1[2],f1s1[3],f1s1[4],f1s1[5],f1s1[6],f1s1[7],f1s1[8],f1s1[9],f1s1[10],
                    f2s1[0],f2s1[1],f2s1[2],f2s1[3],f2s1[4],f2s1[5],f2s1[6],f2s1[7],f2s1[8],f2s1[9],f2s1[10]]
        ###################################################################################
        f1_policy_can_used=agent.collectpolicy(
                                    x=env.f1s[0],y=env.f1s[1],z=env.f1s[2],
                                    vx=env.f1s[3],vy=env.f1s[4],vz=env.f1s[5],
                                    tr=env.f1s[6],tl=env.f1s[7],cl=env.f1s[8],dec=env.f1s[9],straight=env.f1s[10])
        f2_policy_can_used=agent.collectpolicy(
                                    x=env.f2s[0],y=env.f2s[1],z=env.f2s[2],
                                    vx=env.f2s[3],vy=env.f2s[4],vz=env.f2s[5],
                                    tr=env.f2s[6],tl=env.f2s[7],cl=env.f2s[8],dec=env.f2s[9],straight=env.f2s[10])
        f1_s_a=agent.observation_generator([env.f1s[0],env.f1s[1],env.f1s[2],env.f1s[3],env.f1s[4],env.f1s[5],env.f1s[6],
                                 env.f1s[7],env.f1s[8],env.f1s[9],env.f1s[10]],f1_policy_can_used)
        f2_s_a=agent.observation_generator([env.f2s[0],env.f2s[1],env.f2s[2],env.f2s[3],env.f2s[4],env.f2s[5],env.f2s[6],
                                 env.f2s[7],env.f2s[8],env.f2s[9],env.f2s[10]],f2_policy_can_used)

        a=np.append(f1_s_a[0,:].reshape(1,17),f2_s_a[0,:].reshape(1,17),axis=1)
        for j in range(7):
            for k in range(7):
                b=np.append(f1_s_a[j,:].reshape(1,17),f2_s_a[k,:].reshape(1,17),axis=1)
                a=np.append(a,b,axis=0)
        
        s_a=np.append(f1_s_a,f2_s_a,axis=1)
        f1_best_action,f2_best_action=agent.choose_best_policy(s_a)#f_best_action=[acc,tr,tl,cl,dc,straight]
        action_to_memo=np.append(f1_best_action.reshape(1,6),f2_best_action.reshape(1,6),axis=1)
        ########################################################################################################
        action_to_memo=[action_to_memo[0,0],action_to_memo[0,1],action_to_memo[0,2],action_to_memo[0,3],
                        action_to_memo[0,4],action_to_memo[0,5],action_to_memo[0,6],action_to_memo[0,7],
                        action_to_memo[0,8],action_to_memo[0,9],action_to_memo[0,10],action_to_memo[0,11]]
        ###########################################################################################################
        f1vscalar=(f1s1[3]**2+f1s1[4]**2+f1s1[5]**2)**(1/2)
        f2vscalar=(f2s1[3]**2+f2s1[4]**2+f2s1[5]**2)**(1/2)
        fuel_r1=f1fuelcal(f1s1[2],f1vscalar,f1s1[8],f1s1[9],f1s1[10])
        fuel_r2=f2fuelcal(f2s1[2],f2vscalar,f2s1[8],f2s1[9],f2s1[10])
        s_r=situationawarereward(f1s1[0],f1s1[1],f1s1[2],f2s1[0],f2s1[1],f2s1[2])
        # print(s_r)
        d_r1=f1_distodesreward(f1x=f1s1[0],f1y=f1s1[1],f1z=f1s1[2],
                               orgf1x=f1origin[0],orgf1y=f1origin[1],orgf1z=f1origin[2],
                               desf1x=f1destination[0],desf1y=f1destination[1],desf1z=f1destination[2])
        d_r2=f2_distodesreward(f2x=f2s1[0],f2y=f2s1[1],f2z=f2s1[2],
                               orgf2x=f2origin[0],orgf2y=f2origin[1],orgf2z=f2origin[2],
                               desf2x=f2destination[0],desf2y=f2destination[1],desf2z=f2destination[2])
        #######################################################################################################
        totalr=fuel_r1+fuel_r2+s_r+d_r1+d_r2
        # print(totalr)
        # print(totalr)
        #######################################################################################################
        f1s2=env.s1tos2(x=f1s1[0], y=f1s1[1], z=f1s1[2],vx=f1s1[3], vy=f1s1[4], vz=f1s1[5],
             tr=f1s1[6], tl=f1s1[7], cl=f1s1[8], dec=f1s1[9], straight=f1s1[10],
             ch_acc=f1_best_action[0], ch_tr=f1_best_action[1], ch_tl=f1_best_action[2],
             ch_cl=f1_best_action[3], ch_dec=f1_best_action[4], ch_straight=f1_best_action[5])
        f2s2=env.s1tos2(x=f2s1[0], y=f2s1[1], z=f2s1[2],vx=f2s1[3], vy=f2s1[4], vz=f2s1[5],
             tr=f2s1[6], tl=f2s1[7], cl=f2s1[8], dec=f2s1[9], straight=f2s1[10],
             ch_acc=f2_best_action[0], ch_tr=f2_best_action[1], ch_tl=f2_best_action[2],
             ch_cl=f2_best_action[3], ch_dec=f2_best_action[4], ch_straight=f2_best_action[5])
        s2_to_memo=[f1s2[0],f1s2[1],f1s2[2],f1s2[3],f1s2[4],f1s2[5],f1s2[6],f1s2[7],f1s2[8],f1s2[9],f1s2[10],f2s2[0],f2s2[1],f2s2[2],f2s2[3],f2s2[4],f2s2[5],f2s2[6],f2s2[7],f2s2[8],
            f2s2[9],f2s2[10]]
        
        env.update_f1s(f1s2)
        env.update_f2s(f2s2)
       
        if (abs(f1s2[0]-f1destination[0])+abs(f1s2[1]-f1destination[1])+abs(f1s2[2]-f1destination[2]))<=0.3:
            f1done=1
        else:
            f1done=0
        if (abs(f2s2[0]-f2destination[0])+abs(f2s2[1]-f2destination[1])+abs(f2s2[2]-f2destination[2]))<=0.3:
            f2done=1
        else:
            f2done=0
        # if (s_r<=-8) or (totalr<=-5):
        #     f1done=1;f2done=1
        ##########################################################################################################
        done=[f1done,f2done]
        # print(done)
        #########################################################################################################
        DDQNreplayer5000.store(s1_to_memo,action_to_memo,totalr,s2_to_memo,done)######全部存成列表
        totalreward=totalreward+totalr
        # print(totalreward)
        if done==[0,0]:
            continue
        else:
            break

    if done==[0,1]:
        for i in range(500):
            f1s1=env.f1s
            f2s1=env.f2s
            f1origin=env.f1origin;f1destination=env.f1destination
            f2origin=env.f2origin;f2destination=env.f2destination
            ###################################################################################
            s1_to_memo=[f1s1[0],f1s1[1],f1s1[2],f1s1[3],f1s1[4],f1s1[5],f1s1[6],f1s1[7],f1s1[8],f1s1[9],f1s1[10],
                        f2s1[0],f2s1[1],f2s1[2],f2s1[3],f2s1[4],f2s1[5],f2s1[6],f2s1[7],f2s1[8],f2s1[9],f2s1[10]]
            ###################################################################################
            f1_policy_can_used=agent.collectpolicy(
                                        x=env.f1s[0],y=env.f1s[1],z=env.f1s[2],
                                        vx=env.f1s[3],vy=env.f1s[4],vz=env.f1s[5],
                                        tr=env.f1s[6],tl=env.f1s[7],cl=env.f1s[8],dec=env.f1s[9],straight=env.f1s[10])
            f2_policy_can_used=agent.collectpolicy(
                                        x=env.f2s[0],y=env.f2s[1],z=env.f2s[2],
                                        vx=env.f2s[3],vy=env.f2s[4],vz=env.f2s[5],
                                        tr=env.f2s[6],tl=env.f2s[7],cl=env.f2s[8],dec=env.f2s[9],straight=env.f2s[10])
            f1_s_a=agent.observation_generator([env.f1s[0],env.f1s[1],env.f1s[2],env.f1s[3],env.f1s[4],env.f1s[5],env.f1s[6],
                                     env.f1s[7],env.f1s[8],env.f1s[9],env.f1s[10]],f1_policy_can_used)
            f2_s_a=agent.observation_generator([env.f2s[0],env.f2s[1],env.f2s[2],env.f2s[3],env.f2s[4],env.f2s[5],env.f2s[6],
                                     env.f2s[7],env.f2s[8],env.f2s[9],env.f2s[10]],f2_policy_can_used)
    
            a=np.append(f1_s_a[0,:].reshape(1,17),f2_s_a[0,:].reshape(1,17),axis=1)
            for j in range(7):
                for k in range(7):
                    b=np.append(f1_s_a[j,:].reshape(1,17),f2_s_a[k,:].reshape(1,17),axis=1)
                    a=np.append(a,b,axis=0)
            
            s_a=np.append(f1_s_a,f2_s_a,axis=1)
            f1_best_action,f2_best_action=agent.choose_best_policy(s_a)#f_best_action=[acc,tr,tl,cl,dc,straight]
            action_to_memo=np.append(f1_best_action.reshape(1,6),f2_best_action.reshape(1,6),axis=1)
            ########################################################################################################
            action_to_memo=[action_to_memo[0,0],action_to_memo[0,1],action_to_memo[0,2],action_to_memo[0,3],
                            action_to_memo[0,4],action_to_memo[0,5],action_to_memo[0,6],action_to_memo[0,7],
                            action_to_memo[0,8],action_to_memo[0,9],action_to_memo[0,10],action_to_memo[0,11]]
            ###########################################################################################################
            f1vscalar=(f1s1[3]**2+f1s1[4]**2+f1s1[5]**2)**(1/2)
            fuel_r1=f1fuelcal(f1s1[2],f1vscalar,f1s1[8],f1s1[9],f1s1[10])
            s_r=situationawarereward(f1s1[0],f1s1[1],f1s1[2],f2s1[0],f2s1[1],f2s1[2])
            d_r1=f1_distodesreward(f1x=f1s1[0],f1y=f1s1[1],f1z=f1s1[2],
                                   orgf1x=f1origin[0],orgf1y=f1origin[1],orgf1z=f1origin[2],
                                   desf1x=f1destination[0],desf1y=f1destination[1],desf1z=f1destination[2])
            #######################################################################################################
            totalr=fuel_r1+s_r+d_r1
            #######################################################################################################
            f1s2=env.s1tos2(x=f1s1[0], y=f1s1[1], z=f1s1[2],vx=f1s1[3], vy=f1s1[4], vz=f1s1[5],
                 tr=f1s1[6], tl=f1s1[7], cl=f1s1[8], dec=f1s1[9], straight=f1s1[10],
                 ch_acc=f1_best_action[0], ch_tr=f1_best_action[1], ch_tl=f1_best_action[2],
                 ch_cl=f1_best_action[3], ch_dec=f1_best_action[4], ch_straight=f1_best_action[5])
            f2s2=env.s1tos2(x=f2s1[0], y=f2s1[1], z=f2s1[2],vx=f2s1[3], vy=f2s1[4], vz=f2s1[5],
                 tr=f2s1[6], tl=f2s1[7], cl=f2s1[8], dec=f2s1[9], straight=f2s1[10],
                 ch_acc=f2_best_action[0], ch_tr=f2_best_action[1], ch_tl=f2_best_action[2],
                 ch_cl=f2_best_action[3], ch_dec=f2_best_action[4], ch_straight=f2_best_action[5])
            s2_to_memo=[f1s2[0],f1s2[1],f1s2[2],f1s2[3],f1s2[4],f1s2[5],f1s2[6],f1s2[7],f1s2[8],f1s2[9],f1s2[10],f2s2[0],f2s2[1],f2s2[2],f2s2[3],f2s2[4],f2s2[5],f2s2[6],f2s2[7],f2s2[8],
                f2s2[9],f2s2[10]]

            env.update_f1s(f1s2)
            
            if (abs(f1s2[0]-f1destination[0])+abs(f1s2[1]-f1destination[1])+abs(f1s2[2]-f1destination[2]))<=0.3:
                f1done=1
            else:
                f1done=0

            f2done=1
            # if (s_r<=-8) or (totalr<=-5):
            #     f1done=1;f2done=1
            ##########################################################################################################
            done=[f1done,f2done]
            #########################################################################################################
            DDQNreplayer5000.store(s1_to_memo,action_to_memo,totalr,s2_to_memo,done)######全部存成列表
            totalreward=totalreward+totalr
            if done==[0,1]:
                continue
            else:
                break
    if done==[1,0]:
        for i in range(500):
            f1s1=env.f1s
            f2s1=env.f2s
            f1origin=env.f1origin;f1destination=env.f1destination
            f2origin=env.f2origin;f2destination=env.f2destination
            ###################################################################################
            s1_to_memo=[f1s1[0],f1s1[1],f1s1[2],f1s1[3],f1s1[4],f1s1[5],f1s1[6],f1s1[7],f1s1[8],f1s1[9],f1s1[10],
                        f2s1[0],f2s1[1],f2s1[2],f2s1[3],f2s1[4],f2s1[5],f2s1[6],f2s1[7],f2s1[8],f2s1[9],f2s1[10]]
            ###################################################################################
            f1_policy_can_used=agent.collectpolicy(
                                        x=env.f1s[0],y=env.f1s[1],z=env.f1s[2],
                                        vx=env.f1s[3],vy=env.f1s[4],vz=env.f1s[5],
                                        tr=env.f1s[6],tl=env.f1s[7],cl=env.f1s[8],dec=env.f1s[9],straight=env.f1s[10])
            f2_policy_can_used=agent.collectpolicy(
                                        x=env.f2s[0],y=env.f2s[1],z=env.f2s[2],
                                        vx=env.f2s[3],vy=env.f2s[4],vz=env.f2s[5],
                                        tr=env.f2s[6],tl=env.f2s[7],cl=env.f2s[8],dec=env.f2s[9],straight=env.f2s[10])
            f1_s_a=agent.observation_generator([env.f1s[0],env.f1s[1],env.f1s[2],env.f1s[3],env.f1s[4],env.f1s[5],env.f1s[6],
                                     env.f1s[7],env.f1s[8],env.f1s[9],env.f1s[10]],f1_policy_can_used)
            f2_s_a=agent.observation_generator([env.f2s[0],env.f2s[1],env.f2s[2],env.f2s[3],env.f2s[4],env.f2s[5],env.f2s[6],
                                     env.f2s[7],env.f2s[8],env.f2s[9],env.f2s[10]],f2_policy_can_used)
    
            a=np.append(f1_s_a[0,:].reshape(1,17),f2_s_a[0,:].reshape(1,17),axis=1)
            for j in range(7):
                for k in range(7):
                    b=np.append(f1_s_a[j,:].reshape(1,17),f2_s_a[k,:].reshape(1,17),axis=1)
                    a=np.append(a,b,axis=0)
            
            s_a=np.append(f1_s_a,f2_s_a,axis=1)
            f1_best_action,f2_best_action=agent.choose_best_policy(s_a)#f_best_action=[acc,tr,tl,cl,dc,straight]
            action_to_memo=np.append(f1_best_action.reshape(1,6),f2_best_action.reshape(1,6),axis=1)
            ########################################################################################################
            action_to_memo=[action_to_memo[0,0],action_to_memo[0,1],action_to_memo[0,2],action_to_memo[0,3],
                            action_to_memo[0,4],action_to_memo[0,5],action_to_memo[0,6],action_to_memo[0,7],
                            action_to_memo[0,8],action_to_memo[0,9],action_to_memo[0,10],action_to_memo[0,11]]
            ###########################################################################################################
            f2vscalar=(f2s1[3]**2+f2s1[4]**2+f2s1[5]**2)**(1/2)
            fuel_r2=f2fuelcal(f2s1[2],f2vscalar,f2s1[8],f2s1[9],f2s1[10])
            s_r=situationawarereward(f1s1[0],f1s1[1],f1s1[2],f2s1[0],f2s1[1],f2s1[2])
        
            d_r2=f2_distodesreward(f2x=f2s1[0],f2y=f2s1[1],f2z=f2s1[2],
                                   orgf2x=f2origin[0],orgf2y=f2origin[1],orgf2z=f2origin[2],
                                   desf2x=f2destination[0],desf2y=f2destination[1],desf2z=f2destination[2])
            #######################################################################################################
            totalr=fuel_r2+s_r+d_r2
            #######################################################################################################
            f1s2=env.s1tos2(x=f1s1[0], y=f1s1[1], z=f1s1[2],vx=f1s1[3], vy=f1s1[4], vz=f1s1[5],
                 tr=f1s1[6], tl=f1s1[7], cl=f1s1[8], dec=f1s1[9], straight=f1s1[10],
                 ch_acc=f1_best_action[0], ch_tr=f1_best_action[1], ch_tl=f1_best_action[2],
                 ch_cl=f1_best_action[3], ch_dec=f1_best_action[4], ch_straight=f1_best_action[5])
            f2s2=env.s1tos2(x=f2s1[0], y=f2s1[1], z=f2s1[2],vx=f2s1[3], vy=f2s1[4], vz=f2s1[5],
                 tr=f2s1[6], tl=f2s1[7], cl=f2s1[8], dec=f2s1[9], straight=f2s1[10],
                 ch_acc=f2_best_action[0], ch_tr=f2_best_action[1], ch_tl=f2_best_action[2],
                 ch_cl=f2_best_action[3], ch_dec=f2_best_action[4], ch_straight=f2_best_action[5])
            s2_to_memo=[f1s2[0],f1s2[1],f1s2[2],f1s2[3],f1s2[4],f1s2[5],f1s2[6],f1s2[7],f1s2[8],f1s2[9],f1s2[10],f2s2[0],f2s2[1],f2s2[2],f2s2[3],f2s2[4],f2s2[5],f2s2[6],f2s2[7],f2s2[8],
                f2s2[9],f2s2[10]]
            
            env.update_f2s(f2s2)          
            
            f1done=1

            if ((abs(f2s2[0]-f2destination[0])+abs(f2s2[1]-f2destination[1])+abs(f2s2[2]-f2destination[2]))<=0.3):
                f2done=1
            else:
                f2done=0
            # if (s_r<=-8) or (totalr<=-5):
            #     f1done=1;f2done=1
            ##########################################################################################################
            done=[f1done,f2done]
            #########################################################################################################
            DDQNreplayer5000.store(s1_to_memo,action_to_memo,totalr,s2_to_memo,done)######全部存成列表
            totalreward=totalreward+totalr
            if done==[1,0]:
                continue
            else:
                break
    return totalreward
    
    
a=agentplaywithenv(env,agent)
    
    