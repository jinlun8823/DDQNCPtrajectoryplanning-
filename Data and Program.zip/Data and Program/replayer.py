import numpy as np
import pandas as pd
class DDQNreplayer:##经验回放的实现
    def __init__(self,capacity):#经验回放池参数
        self.memory=pd.DataFrame(index=range(capacity),
        columns=['state','action','reward','next_state','done'])
        self.i=0
        self.count=0
        self.capacity=capacity
    def store(self,*args):#存储
        self.memory.loc[self.i]=args
        self.i=(self.i+1)%self.capacity
        self.count=min(self.count+1,self.capacity)
    def sample(self,size):#采样
        indices=np.random.choice(self.count,size=size)
        a=(np.stack(self.memory.loc[indices,field]) for field in self.memory.columns)
        return a
    def train_data_generator(self,s,a):
        train_data=np.append(s,a,axis=1)
        return train_data
#s1:[0:f1s1x,1:f1s1y,2:f1s1z,3:f1s1vscalarx,4:f1s1vscalary,5:f1s1vscalarz
#        ,6:f1s1turnring,7:f1s1turnling,8:f1s1climbing,9:f1s1decenting,10:f1s1straghting,
#        11:f2s1x,12:f2s1y,13:f2s1z,14:f2s1vscalarx,15:f2s1vscalary,16:f2s1vscalarz
#        ,17:f2s1turnring,18:f2s1turnling,19:f2s1climbing,20:f2s1decenting,21:f2s1straghting]   (22个值)
#a:[f1acc,f1tr,f1tl,f1cl,f1de,f1straight,
#   f2acc,f2tr,f2tl,f2cl,f2de,f2straight]                                        (12个值)
#reward:[10]                                                                     (1个值)
#next_state=[f1s2x,f1s2y,f1s2z,f1s2vscalarx,f1s2vscalary,f1s2vscalarz
#        ,f1s2turnring,f1s2turnling,f1s2climbing,f1s2decenting,f1s2straghting,
#        f2s2x,f2s2y,f2s2z,f2s2vscalarx,f2s2vscalary,f2s2vscalarz
#        ,f2s2turnring,f2s2turnling,f2s2climbing,f2s2decenting,f2s2straghting]   (22个值)
#done=[1,0]                                                                      (2个值)
#共59个
#训练样本结构：[s,a]:[f1s1x,f1s1y,f1s1z,f1s1vscalarx,f1s1vscalary,f1s1vscalarz,f1s1turnring,
#                    f1s1turnling,f1s1climbing,f1s1decenting,f1s1straghting,f2s1x,f2s1y,f2s1z,
#                    f2s1vscalarx,f2s1vscalary,f2s1vscalarz,f2s1turnring,f2s1turnling,f2s1climbing,
#                    f2s1decenting,f2s1straghting,f1acc,f1tr,f1tl,f1cl,f1de,f1straight,f2acc,f2tr,f2tl,f2cl,f2de,f2straight)
#####[s,a]:(22+12=34个值)，也是放到训练集里的东西



# #test#
DDQNreplayer5000=DDQNreplayer(5000)
# DDQNreplayer5000.store([0,0,9.2,0,600,0,0,0,0,0,1,0,100,9.5,600,0,0,0,0,0,0,1],[0,0,0,0,0,1,0,0,0,0,0,1],8,[1,2,3,45,5,4,0,0,0,0,1,2,3,5,8,5,0,0,0,0,0,1],[0,0])
# s1,a,r,s2,done=DDQNreplayer5000.sample(1)
# traindata=DDQNreplayer5000.train_data_generator(s1,a)
#test#








###输进去是列表，取出来是元组




