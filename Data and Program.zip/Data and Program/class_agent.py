import numpy as np
from replayer import DDQNreplayer
from networkcreator import network_creator
from replayer import DDQNreplayer5000

class DDQNagent:######智能体的强化学习建模
    def __init__(self,gama=0.99,epsilon=0.35,replayer_capacity=5000):#######智能体参数
        self.epsilon=epsilon
        self.gama=gama
        self.replayer_capacity=replayer_capacity
        ##生成经验池（创建时自带）
        self.Replayer=DDQNreplayer(self.replayer_capacity)
        ##生成评估网络和策略网络（创建时自带）
        self.evanet=network_creator(input_shape=34,output_shape=1)
        self.targetnet=network_creator(input_shape=34,output_shape=1)
        self.targetnet.set_weights(self.evanet.get_weights())
        
    def collectpolicy(self,x,y,z,vx,vy,vz,tr,tl,cl,dec,straight):#根据当前状态获取可用策略
        
        if  tr==0 and tl==0 and cl==0 and dec==0 and straight==1: #平飞时，平飞时才能加速，其他状态不行
            if  500<(vx**2+vy**2+vz**2)**(1/2)<1000 and 8.9<=z<=9.8:                 #没有超速度约束时
                policycanbeused={1:(1,0,0,0,0,1),2:(-1,0,0,0,0,1),3:(0,1,0,0,0,0),4:(0,0,1,0,0,0),
                                 5:(0,0,0,1,0,0),6:(0,0,0,0,1,0),7:(0,0,0,0,0,1)}        
            elif (vx**2+vy**2+vz**2)**(1/2)>=1000 and 8.9<=z<=9.8:#超速时，只能减速
                policycanbeused={1:(-1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,1,0,0),5:(0,0,0,0,1,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            elif (vx**2+vy**2+vz**2)**(1/2)<=500 and 8.9<=z<=9.8:#太慢时候，只能加速
                policycanbeused={1:(1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,1,0,0),5:(0,0,0,0,1,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}#第七个凑数用
            if  500<(vx**2+vy**2+vz**2)**(1/2)<1000 and z<=8.9:                 #没有超速度约束时
                policycanbeused={1:(1,0,0,0,0,1),2:(-1,0,0,0,0,1),3:(0,1,0,0,0,0),4:(0,0,1,0,0,0),
                                 5:(0,0,0,1,0,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}        
            elif (vx**2+vy**2+vz**2)**(1/2)>=1000 and z<=8.9:#超速时，只能减速
                policycanbeused={1:(-1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,1,0,0),5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            elif (vx**2+vy**2+vz**2)**(1/2)<=500 and z<=8.9:#太慢时候，只能加速
                policycanbeused={1:(1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,1,0,0),5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}#第七个凑数用
            if  500<(vx**2+vy**2+vz**2)**(1/2)<1000 and z>=9.8:                 #没有超速度约束时
                policycanbeused={1:(1,0,0,0,0,1),2:(-1,0,0,0,0,1),3:(0,1,0,0,0,0),4:(0,0,1,0,0,0),
                                 5:(0,0,0,0,1,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}        
            elif (vx**2+vy**2+vz**2)**(1/2)>=1000 and z>=9.8:#超速时，只能减速
                policycanbeused={1:(-1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,0,1,0),5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            elif (vx**2+vy**2+vz**2)**(1/2)<=500 and z>=9.8:#太慢时候，只能加速
                policycanbeused={1:(1,0,0,0,0,1),2:(0,1,0,0,0,0),3:(0,0,1,0,0,0),
                                 4:(0,0,0,0,1,0),5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}#第七个凑数用
        if tr==1 and tl==0 and cl==0 and dec==0 and straight==0:   #右转弯时
            policycanbeused={1:(0,1,0,0,0,0),2:(0,0,1,0,0,0),3:(0,0,0,0,0,1),
                             4:(0,1,0,0,0,0),5:(0,0,1,0,0,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}####可以继续右转，可以左转，可以改平,4-7凑数用
        if tr==0 and tl==1 and cl==0 and dec==0 and straight==0:   #左转弯时
            policycanbeused={1:(0,1,0,0,0,0),2:(0,0,1,0,0,0),3:(0,0,0,0,0,1),
                             4:(0,1,0,0,0,0),5:(0,0,1,0,0,0),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}#4-7凑数用
        if tr==0 and tl==0 and cl==1 and dec==0 and straight==0:   #爬升时
            if 8.9<=z<=9.8:
                policycanbeused={1:(0,0,0,1,0,0),2:(0,0,0,0,1,0),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            if z<=8.9:
                policycanbeused={1:(0,0,0,1,0,0),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            if z>=9.8:
                policycanbeused={1:(0,0,0,0,1,0),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
        #     if (abs(z-9.2)>=0.01 or abs(z-9.5)>=0.01 or abs(z-8.9)>=0.01 or abs(z-9.8)>=0.01):
        #         policycanbeused={1:(0,0,0,1,0,0),2:(0,0,0,1,0,0),3:(0,0,0,1,0,0),4:(0,0,0,1,0,0),
        #                          5:(0,0,0,1,0,0),6:(0,0,0,1,0,0),7:(0,0,0,1,0,0)}##必须到达高度层才能改平
        #     elif (abs(z-9.2)<=0.012 or abs(z-9.5)<=0.012 or abs(z-8.9)<=0.012 or abs(z-9.8)<=0.012):
        #         policycanbeused={1:(0,0,0,0,0,1),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),
        #                          4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),
        #                          7:(0,0,0,0,0,1),8:(0,0,0,0,0,1)}#到达高度层必须改平
        if tr==0 and tl==0 and cl==0 and dec==1 and straight==0:   #下降时
            if 8.9<=z<=9.8:
                policycanbeused={1:(0,0,0,1,0,0),2:(0,0,0,0,1,0),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            if z<=8.9:
                policycanbeused={1:(0,0,0,1,0,0),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
            if z>=9.8:
                policycanbeused={1:(0,0,0,0,1,0),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),5:(0,0,0,0,0,1),
                                 6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}
        #     if (abs(z-9.2)>=0.01 or abs(z-9.5)>=0.01 or abs(z-8.9)>=0.01 or abs(z-9.8)>=0.01):
        #         policycanbeused={1:(0,0,0,0,1,0),2:(0,0,0,0,1,0),3:(0,0,0,0,1,0),4:(0,0,0,0,1,0),
        #                          5:(0,0,0,0,1,0),6:(0,0,0,0,1,0),7:(0,0,0,0,1,0)}##必须到达高度层才能改平
        #     elif (abs(z-9.2)<=0.012 or abs(z-9.5)<=0.012 or abs(z-8.9)<=0.012 or abs(z-9.8)<=0.012):
        #         policycanbeused={1:(0,0,0,0,0,1),2:(0,0,0,0,0,1),3:(0,0,0,0,0,1),4:(0,0,0,0,0,1),
        #                          5:(0,0,0,0,0,1),6:(0,0,0,0,0,1),7:(0,0,0,0,0,1)}#到达高度层必须改平
        return policycanbeused

    def observation_generator(self,observation,collectpolicy):#observation:[1,2,3,4],collectpolicy:{[]}
        a=np.array(observation)
        a=np.reshape(a,(1,11))
        # print('1:',collectpolicy[1])
        c=np.array(list(collectpolicy[1]))
        # print('c:',c)
        c=np.reshape(c,(1,6))
        obsarrayall=np.append(a,c,axis=1)
        for i in collectpolicy.keys():
            a=np.array(observation)
            a=np.reshape(a,(1,11))
            c=np.array(list(collectpolicy[i]))
            c=np.reshape(c,(1,6))
            obsarray=np.append(a,c,axis=1)
            obsarrayall=np.append(obsarrayall,obsarray,axis=0)
        obsarrayall=np.delete(obsarrayall,[1],axis=0)
        return obsarrayall
    
    def choose_best_policy(self,obsarrayall): ##决策，e-greedy,这个在生成经验池和估计下一步q值都是要用的
        q_value=self.evanet.predict(obsarrayall)
        obsarrayallandqs=np.append(obsarrayall,q_value,axis=-1)
        arrnew=obsarrayallandqs[obsarrayallandqs[:,obsarrayallandqs.shape[1]-1].argsort(),:]
        arrnew=arrnew[::-1,:]
        if np.random.rand()>=self.epsilon:
            f1_decide_policy=arrnew[0,11:17]
            f2_decide_policy=arrnew[0,28:34]
        else:
            f1_decide_policy=arrnew[np.random.randint(0,arrnew.shape[0]),11:17]
            f2_decide_policy=arrnew[np.random.randint(0,arrnew.shape[0]),28:34]
        return f1_decide_policy,f2_decide_policy
    
    def learn_policy_step(self):###更新策略,俩神经网络
        
        observation,action,reward,next_observation,done=DDQNreplayer5000.sample(1)
        ######################################################################################next_state
        f1_next_state=[next_observation[0,0],next_observation[0,1],next_observation[0,2],
                       next_observation[0,3],next_observation[0,4],next_observation[0,5],next_observation[0,6],next_observation[0,7],
                       next_observation[0,8],next_observation[0,9],next_observation[0,10]]
        f2_next_state=[next_observation[0,11],next_observation[0,12],next_observation[0,13],
                       next_observation[0,14],next_observation[0,15],next_observation[0,16],next_observation[0,17],next_observation[0,18],
                       next_observation[0,19],next_observation[0,20],next_observation[0,21]]
        f1_actions_canbeused=self.collectpolicy(next_observation[0,0],next_observation[0,1],next_observation[0,2],
                          next_observation[0,3],next_observation[0,4],next_observation[0,5],next_observation[0,6],next_observation[0,7],
                          next_observation[0,8],next_observation[0,9],next_observation[0,10])
        f2_actions_canbeused=self.collectpolicy(next_observation[0,11],next_observation[0,12],next_observation[0,13],
                          next_observation[0,14],next_observation[0,15],next_observation[0,16],next_observation[0,17],next_observation[0,18],
                          next_observation[0,19],next_observation[0,20],next_observation[0,21])
        f1_stateaction=self.observation_generator(f1_next_state,f1_actions_canbeused)
        f2_stateaction=self.observation_generator(f2_next_state,f2_actions_canbeused)
        
        ob_ac_pairs=np.append(f1_stateaction,f2_stateaction,axis=1)##############array[s1,a1,s2,a2]的矩阵
        
        f1_best_action,f2_best_action=self.choose_best_policy(ob_ac_pairs)###########输出了不同航空器的最优策略
        
        f1_next_state=np.reshape(f1_next_state,(1,11))
        f2_next_state=np.reshape(f2_next_state,(1,11))##########每个航空器的当前状态
        
        f1_best_action=np.reshape(f1_best_action,(1,6))
        f2_best_action=np.reshape(f2_best_action,(1,6))###########################每个航空器当前状态下的最优策略
        
        f1_s_a=np.append(f1_next_state,f1_best_action,axis=1)
        f2_s_a=np.append(f2_next_state,f2_best_action,axis=1)
        
        num_input_net=np.append(f1_s_a,f2_s_a,axis=1)########st+1,best at+1
        
        target=reward+self.gama*self.targetnet.predict(num_input_net)
        # print(target)
        ##############us=reward+gama*q(st+1,best at+1)
        ########################################################################################current_state
        ######################################################################################next_state
        f1_current_state=[observation[0,0],observation[0,1],observation[0,2],
                      observation[0,3],observation[0,4],observation[0,5],observation[0,6],observation[0,7],
                      observation[0,8],observation[0,9],observation[0,10]]
        f1_current_state=np.reshape(f1_current_state,(1,11))
        f2_current_state=[observation[0,11],observation[0,12],observation[0,13],
                       observation[0,14],observation[0,15],observation[0,16],observation[0,17],observation[0,18],
                      observation[0,19],observation[0,20],observation[0,21]]
        f2_current_state=np.reshape(f2_current_state,(1,11))
        f1_action=action[0,0:6]
        f1_action=np.reshape(f1_action,(1,6))
        f2_action=action[0,6:12]
        f2_action=np.reshape(f2_action,(1,6))
        f1_s_a=np.append(f1_current_state,f1_action,axis=1)
        f2_s_a=np.append(f2_current_state,f2_action,axis=1)
        current_s_a=np.append(f1_s_a,f2_s_a,axis=1)
        ################################输入标准化[f1x,f1y,f1z,f1vx,f1vy,f1vz,tr,tl,c,d,s]
        current_s_a[0,0]=current_s_a[0,0]/100;current_s_a[0,1]=current_s_a[0,1]/100;current_s_a[0,2]=current_s_a[0,2]/100
        current_s_a[0,3]=current_s_a[0,3]/600;current_s_a[0,4]=current_s_a[0,4]/600; current_s_a[0,5]=current_s_a[0,5]/600
        
        current_s_a[0,17]=current_s_a[0,17]/100;current_s_a[0,18]=current_s_a[0,18]/100;current_s_a[0,19]=current_s_a[0,19]/100
        current_s_a[0,20]=current_s_a[0,20]/600;current_s_a[0,21]=current_s_a[0,21]/600; current_s_a[0,22]=current_s_a[0,22]/600
        
        ############################target标准化
        target=(target+50000)/900########单步期望-10，2500步期望-10*2500，根据3xigama估算均方差16，16*16*2500开根号等于800，凑个整用900
        ########################################################
        self.evanet.fit(current_s_a,target,verbose=1)####拟合,训练网络
        ###agent.evanet.fit(当前的状态策略对，target)
    def learn_policy_eps(self):
        self.targetnet.set_weights(self.evanet.get_weights())
    def change_eps(self,newe):
        self.epsilon=newe
        
        
agent=DDQNagent()
# agent.change_eps(0.0001)
        