def f1_distodesreward(f1x,f1y,f1z,orgf1x,orgf1y,orgf1z,desf1x,desf1y,desf1z):#####算到达目的地距离的奖励

    d1todes=((f1x-desf1x)**2+(f1y-desf1y)**2)**(1/2)
    orignd1=((orgf1x-desf1x)**2+(orgf1y-desf1y)**2+(orgf1z-desf1z)**2)**(1/2)
    if d1todes<=1 and (f1z-desf1z)**2<=0.05:
        reward1=50
    else:
        reward1=0
    approach_reward1=(((-d1todes+orignd1)*10)/orignd1)-10+reward1
    
    return approach_reward1

def f2_distodesreward(f2x,f2y,f2z,orgf2x,orgf2y,orgf2z,desf2x,desf2y,desf2z):
    
    d2todes=((f2x-desf2x)**2+(f2y-desf2y)**2)**(1/2)

    orignd2=((orgf2x-desf2x)**2+(orgf2y-desf2y)**2+(orgf2z-desf2z)**2)**(1/2)
    if d2todes<=1 and (f2z-desf2z)**2<=0.05:
        reward2=50
    else:
        reward2=0
    approach_reward2=(((-d2todes+orignd2)*10)/orignd2)-10+reward2
    
    return approach_reward2

#test#
f1_dreward=f1_distodesreward(f1x=0,f1y=0,f1z=9.5,orgf1x=0,orgf1y=0,orgf1z=9.5,desf1x=100,desf1y=100,desf1z=9.5)
f2_dreward=f2_distodesreward(f2x=0,f2y=100,f2z=9.2,orgf2x=0,orgf2y=100,orgf2z=9.5,desf2x=100,desf2y=0,desf2z=9.2)
total_dreward=f1_dreward+f2_dreward
#test#





