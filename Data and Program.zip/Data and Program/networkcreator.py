
import keras
from keras import optimizers
def network_creator(input_shape,output_shape):####生成神经网络的
    networkmodel=keras.models.Sequential()
    networkmodel.add(keras.layers.Dense(256,activation='relu',input_dim=input_shape))
    networkmodel.add(keras.layers.Dense(64,activation='relu'))
    networkmodel.add(keras.layers.Dense(output_shape))
    networkmodel.compile(loss='mae',optimizer=optimizers.RMSprop())
    return networkmodel





# #test#
# import numpy as np
# from replayer import DDQNreplayer5000
# targetnet=network_creator(34, 1)
# targetnet.summary()
# target=np.array([1,2,3,4,5])
# s1,a,r,s2,done=DDQNreplayer5000.sample(5)
# traindata=DDQNreplayer5000.train_data_generator(s1,a)
# targetnet.fit(traindata,target,verbose=1)
# #test#