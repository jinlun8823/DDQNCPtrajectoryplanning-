from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=18.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure()
ax = fig.gca(projection='3d')
# ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 18.5,
        }#############x,y,z标签的字体
z_major_locator=MultipleLocator(0.3)
#把x轴的刻度间隔设置为1，并存在变量里

ax.zaxis.set_major_locator(z_major_locator)
ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
ax.xaxis.set_major_formatter(FormatStrFormatter('%.01f'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.01f'))
ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['color'] = "gray"##############x,y,z网格线颜色
ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
ax.xaxis._axinfo["grid"]['color'] = "gray"
ax.xaxis._axinfo["grid"]['linestyle'] = "-"
ax.yaxis._axinfo["grid"]['color'] = "gray"
ax.yaxis._axinfo["grid"]['linestyle'] = "-"
ax.set_xlim(111,116)
ax.set_ylim(22,26)
ax.set_zlim(9.1,10.4)
# plt.axes.get_yaxis().set_visible(False)
# plt.axes.get_xaxis().set_visible(False)
plt.axis('off')
# x1=np.array([[114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]]);
# y1=np.array([[24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]])
# x1,y1=np.meshgrid(x1,y1)
# Z=0*x1+0*y1+8.9
# ax.plot_surface(x1,y1,Z,color='black',alpha=1)
# plt.show()
# x2=[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
# y2=[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
# ax.plot_surface(x2,y2,color='skyblue',alpha=0.8)
# plt.show()
# x3=[113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
# y3=[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
# plt.plot(x3,y3,8.9,color='green')
# x4=[111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
# y4=[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
# plt.plot(x4,y4,8.9,color='orange')
# x6=[114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
# y6=[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
# plt.plot(x6,y6,8.9,color='red')
# x5=[113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
#     114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
# y5=[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
#     22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
# plt.plot(x5,y5,8.9,color='blue')
    
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.pyplot as plt
def plotenv():
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 8.9,'8.9')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 9.2,'9.2')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 9.5,'9.5')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 9.8,'9.8')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 10.1,'10.1')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 10.4,'10.4')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.4)
    ax.add_collection3d(AR01)
    ax.text(116.4, 23, 10.7,'10.7')
    
    
    
    ###AR02
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x =[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.4)
    ax.add_collection3d(AR02)
    ############################################################################################AR03
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.4)
    ax.add_collection3d(AR03)
    #####################################################################ar04
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.4)
    ax.add_collection3d(AR04)
    #############################################################################################ar06
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.5)
    ax.add_collection3d(AR06)
    #########################################################################################AR05
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='gray',alpha=0.4)
    ax.add_collection3d(AR05)
    ax.view_init(28,283)
plotenv()
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from guidence_policy import Aircraft,decidebyguidence, decidebyguidenceonlyone,th_center,th_r
from action_can_be_choosed import get_action_space
from state_change import action
from matplotlib.patches import Circle
def is_same_altitude(x,y):
        if abs(x-y)<=0.1:
            issame=1
        else:
            issame=0
        return issame
A0=Aircraft(org=[110.5,23.5,10.1,600,80],des=[115.7,23.3,10.1],name='0',state=[110.5,23.5,10.1,600,80],statelis=[])
A1=Aircraft(org=[115.7,23.3,10.1,700,260],des=[110.5,23.5,10.1],name='1',state=[115.7,23.3,10.1,700,260],statelis=[])
A2=Aircraft(org=[114,25.08,10.1,600,180],des=[114.1,22.2,10.1],name='2',state=[114,25.08,10.1,600,180],statelis=[])
A3=Aircraft(org=[114.1,22.2,10.1,700,350],des=[114,25.08,10.1],name='3',state=[114.1,22.2,10.1,700,350],statelis=[])
A4=Aircraft(org=[111.2,24.2,10.1,600,180],des=[111.3,22.,10.1],name='4',state=[111.2,24.2,10.1,600,180],statelis=[])
A5=Aircraft(org=[111.3,22,10.1,600,190],des=[111.2,24.2,10.1],name='5',state=[111.3,22,10.1,600,190],statelis=[])
A6=Aircraft(org=[113,24.4,10.1,600,180],des=[113.5,22,10.1],name='6',state=[113,24.4,10.1,600,180],statelis=[])
A7=Aircraft(org=[113.5,22,10.1,600,350],des=[113,24.4,10.1],name='7',state=[113.5,22,10.1,600,350],statelis=[])
A8=Aircraft(org=[115,24.7,10.1,760,190],des=[114.6,22.7,10.1],name='8',state=[115,24.7,10.1,760,190],statelis=[])
A9=Aircraft(org=[114.6,22.7,10.1,450,20],des=[115,24.7,10.1],name='9',state=[114.6,22.7,10.1,450,20],statelis=[])
Alis=[A0,A1,A2,A3,A4,A5,A6,A7,A8,A9]

# th_center=[60,50];th_r=20
# ax = fig.gca(projection='3d')

#######################################################################main##################
for i in range(3900):
    nameset={'0','1','2','3','4','5','6','7','8','9'}
    #########1s的小循环
    de_array=np.zeros((10,10))
    acdic={}   
    while nameset != set():
        for i in range(10):
            for j in range(10):
                if (str(i) not in nameset) and (str(j) not in nameset) or i==j:
                    de_array[i,j]=-999
                else:
                    de_array[i,j]=is_same_altitude(Alis[i].state[2],Alis[j].state[2])*((Alis[i].state[0]-Alis[j].state[0])**2+(Alis[i].state[1]-Alis[j].state[1])**2)**(1/2)
                if de_array[i,j]>1:
                    de_array[i,j]=-de_array[i,j]+1000

        pos = np.unravel_index(np.argmax(de_array),de_array.shape)
        
        if (str(pos[0]) in nameset) and (str(pos[1]) in nameset):    
            a=decidebyguidence(Alis[pos[0]].state,Alis[pos[1]].state,Alis[pos[0]].des,Alis[pos[1]].des)
            a1=a//10
            a2=a%10
            Alis[pos[0]].state=action(Alis[pos[0]].state,a1)
            Alis[pos[1]].state=action(Alis[pos[1]].state,a2)
            Alis[pos[0]].statelis.append(Alis[pos[0]].state)
            Alis[pos[1]].statelis.append(Alis[pos[1]].state)
            acdic[Alis[pos[0]].name]=round(a1)
            acdic[Alis[pos[1]].name]=round(a2)
            nameset.remove(Alis[pos[0]].name)
            nameset.remove(Alis[pos[1]].name)
        elif (str(pos[0]) not in nameset) and (str(pos[1]) in nameset):
            a= decidebyguidenceonlyone(Alis[pos[0]].state,Alis[pos[1]].state,flight1action=acdic[Alis[pos[0]].name],des1=Alis[pos[0]].des,des2=Alis[pos[1]].des)
            a2=a%10
            Alis[pos[1]].state=action(Alis[pos[1]].state,a2)
            Alis[pos[1]].statelis.append(Alis[pos[1]].state)
            acdic[Alis[pos[1]].name]=round(a2)
            nameset.remove(Alis[pos[1]].name)
        elif (str(pos[0]) in nameset) and (str(pos[1]) not in nameset):
            a= decidebyguidenceonlyone(Alis[pos[1]].state,Alis[pos[0]].state,flight1action=acdic[Alis[pos[1]].name],des1=Alis[pos[1]].des,des2=Alis[pos[0]].des)
            a2=a%10
            Alis[pos[0]].state=action(Alis[pos[0]].state,a2)
            Alis[pos[0]].statelis.append(Alis[pos[0]].state)
            acdic[Alis[pos[0]].name]=round(a2) 
            nameset.remove(Alis[pos[0]].name)
def plotdata(Aircraf):
    x=[]
    y=[]
    z=[]
    H=[]
    t=[]
    for i in range(3900):
        x.append(Aircraf.statelis[i][0])
        y.append(Aircraf.statelis[i][1])
        z.append(Aircraf.statelis[i][2])
        H.append(Aircraf.statelis[i][4])
        t.append(i)
    return x,y,z,H,t
x0,y0,z0,H0,t0=plotdata(A0)
x1,y1,z1,H1,t1=plotdata(A1)
x2,y2,z2,H2,t2=plotdata(A2)
x3,y3,z3,H3,t3=plotdata(A3)
x4,y4,z4,H4,t4=plotdata(A4)
x5,y5,z5,H5,t5=plotdata(A5)
x6,y6,z6,H6,t6=plotdata(A6)
x7,y7,z7,H7,t7=plotdata(A7)
x8,y8,z8,H8,t8=plotdata(A8)
x9,y9,z9,H9,t9=plotdata(A9)
surf=ax.scatter(x1, y1,z1,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x2, y2,z2,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x3, y3,z3,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x4, y4,z4,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x5, y5,z5,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x6, y6,z6,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x7, y7,z7,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x8, y8,z8,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x9, y9,z9,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x0, y0,z0,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)   
# ax.scatter(x0[300], y0[300],z0[300], marker=CustomMarker1("icon", H0[300]), c="red", s=200)
# ax.scatter(x1[370], y1[370], z1[370],marker=CustomMarker1("icon", H1[370]), c="blue", s=200)
# ax.scatter(x2[300], y2[300], z2[300],marker=CustomMarker1("icon", H2[300]), c="green", s=200)
# ax.scatter(x3[370], y3[370], z3[370],marker=CustomMarker1("icon", H3[370]), c="purple", s=200)
# ax.scatter(x4[300], y4[300],z4[300], marker=CustomMarker1("icon", H4[300]), c="orange", s=200)
# ax.scatter(x5[370], y5[370], z5[370],marker=CustomMarker1("icon", H5[370]), c="yellow", s=200)
# ax.scatter(x6[300], y6[300],z6[300], marker=CustomMarker1("icon", H6[300]), c="black", s=200)
# ax.scatter(x7[370], y7[370],z7[370], marker=CustomMarker1("icon", H7[370]), c="gray", s=200)
# ax.scatter(x8[300], y8[300],z8[300], marker=CustomMarker1("icon", H8[300]), c="deeppink", s=200)
# ax.scatter(x9[370], y9[370],z9[370], marker=CustomMarker1("icon", H9[370]), c="blue", s=200) 
cbar=fig.colorbar(surf, shrink=0.7, aspect=15)

cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字


u = np.linspace(0,2*np.pi,50)  # 把圆分按角度为50等分
h = np.linspace(0,1.8,10)        # 把高度1均分为20份
# th_center
x =(th_r-0.1)*np.outer(np.sin(u),np.ones(len(h)))+th_center[0]  # x值重复20次
y =(th_r-0.1)*np.outer(np.cos(u),np.ones(len(h)))+th_center[1] # y值重复20次
z = np.outer(np.ones(len(u)),h)+8.9   # x，y 对应的高度

# Plot the surface
ax.plot_surface(x, y, z, color='orangered',alpha=0.4)
# cbar=fig.colorbar(surf, shrink=0.7, aspect=15)

# cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字
# plt.show()

# from mpl_toolkits.mplot3d import Axes3D
# from mpl_toolkits.mplot3d.art3d import Poly3DCollection
# import matplotlib.pyplot as plt
# fig = plt.figure()
# ax = Axes3D(fig)
# x = [0,1,1,0]
# y = [0,0,1,1]
# z = [0,1,0,1]
# verts = [list(zip(x,y,z))]
# ax.add_collection3d(Poly3DCollection(verts))
# plt.show()

#############################################################################################二维可视化

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.axisartist.parasite_axes import HostAxes, ParasiteAxes
import pandas as pd 
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=18.5##########小四
plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
plt.rcParams["mathtext.fontset"]='stix'
ax2=plt.gca()
fig = plt.figure(1) #定义figure，（1）中的1是什么
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为10，并存在变量里
ax2.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax2.yaxis.set_major_locator(y_major_locator)
# plt.xlim(-0.2,1.3)
# plt.ylim(-0.2,1.3)
ax2.set_aspect(1)
ax_cof = HostAxes(fig, [0, 0, 0.9, 0.9])
ARx1=[114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85];
ARy1=[24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
plt.plot(ARx1,ARy1,color='m')
ARx2=[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
ARy2=[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
plt.plot(ARx2,ARy2,color='skyblue')
ARx3=[113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
ARy3=[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
plt.plot(ARx3,ARy3,color='green')
ARx4=[111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
ARy4=[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
plt.plot(ARx4,ARy4,color='orange')
ARx6=[114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
ARy6=[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
plt.plot(ARx6,ARy6,color='blue')
ARx5=[113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
    114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
ARy5=[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
    22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
plt.plot(ARx5,ARy5,color='gray')
k=0;
ax2.set_xlabel(''+'$\mathrm{'+'Longitude'+'}$',fontdict=font) #X轴标签
ax2.set_ylabel(''+'$\mathrm{'+'Latitude'+'}$',fontdict=font) #Y轴标签
surf=ax2.scatter(x1, y1,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x2, y2,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x3, y3,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x4, y4,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x5, y5,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x6, y6,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x7, y7,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x8, y8,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x9, y9,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax2.scatter(x0, y0,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)

cbar=fig.colorbar(surf, shrink=0.7, aspect=10)

cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字
plt.tick_params(pad=-0)####################################################################轴值与轴的位置调整
ax2.set_xlabel(''+'$\mathrm{'+'Lon/degree'+'}$',fontdict=font,size=18.5,labelpad=2)########labelpad调轴字间距
ax2.set_ylabel(''+'$\mathrm{'+'Lat/degree'+'}$',fontdict=font,size=18.5,labelpad=2)

# ax.set_zlabel('高度'+'$\mathrm{'+'/o'+'}$',fontdict=font,size=18.5,labelpad=2)

################################################################
circle = Circle((th_center[0],th_center[1]), radius=th_r-0.08, facecolor="royalblue", edgecolor="royalblue")

ax2.add_patch(circle)
from matplotlib import pyplot as plt
from matplotlib.path import Path
import numpy as np



# '通过Path类自定义marker'
#定义旋转矩阵
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
    
iconMat = 100*np.array([[0, 9],[1,8],
			[1, 2],
			[7, -3],
			[7, -6],
			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.8],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])

class CustomMarker1(Path):
    def __init__(self, icon, az):
         if icon == "icon": 
             verts = iconMat  
         vertices = rot(verts, az)  
         super().__init__(vertices)


ax2.scatter(x0[500], y0[500], marker=CustomMarker1("icon", H0[500]), c="red", s=250)
ax2.scatter(x1[1000], y1[1000], marker=CustomMarker1("icon", H1[1000]), c="blue", s=250)
ax2.scatter(x2[500], y2[500], marker=CustomMarker1("icon", H2[500]), c="green", s=250)
ax2.scatter(x3[570], y3[570], marker=CustomMarker1("icon", H3[570]), c="purple", s=250)
ax2.scatter(x4[300], y4[300], marker=CustomMarker1("icon", H4[300]), c="orange", s=250)
ax2.scatter(x5[570], y5[570], marker=CustomMarker1("icon", H5[570]), c="yellow", s=250)
ax2.scatter(x6[500], y6[500], marker=CustomMarker1("icon", H6[500]), c="black", s=250)
ax2.scatter(x7[570], y7[570], marker=CustomMarker1("icon", H7[570]), c="gray", s=250)
ax2.scatter(x8[500], y8[500], marker=CustomMarker1("icon", H8[500]), c="deeppink", s=250)
ax2.scatter(x9[570], y9[570], marker=CustomMarker1("icon", H9[570]), c="blue", s=250)


plt.show()




