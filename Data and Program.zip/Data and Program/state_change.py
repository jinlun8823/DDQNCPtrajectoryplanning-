# -*- coding: utf-8 -*-
import numpy as np

#state=[x,y,h,v,d]
def action(state,act):
    state_copy=state.copy()
    if act==1:#####turn left
        state_copy[4]=state_copy[4]-10
        state_copy[0]=state_copy[0]+state_copy[3]*np.cos(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000###度/s
        state_copy[1]=state_copy[1]+state_copy[3]*np.sin(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
    if act==2:#####turn right
        state_copy[4]=state_copy[4]+10
        state_copy[0]=state_copy[0]+state_copy[3]*np.cos(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000###km/s
        state_copy[1]=state_copy[1]+state_copy[3]*np.sin(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
    if act==3:#####straight
        state_copy[0]=state_copy[0]+state_copy[3]*np.cos(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
        state_copy[1]=state_copy[1]+state_copy[3]*np.sin(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
    if act==4:#####climb
        state_copy[2]=state_copy[2]+10/1000    
        state_copy[0]=state_copy[0]+state_copy[3]*np.cos(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
        state_copy[1]=state_copy[1]+state_copy[3]*np.sin(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
    if act==5:#####descent
        state_copy[2]=state_copy[2]-10/1000 
        state_copy[0]=state_copy[0]+state_copy[3]*np.cos(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
        state_copy[1]=state_copy[1]+state_copy[3]*np.sin(0.5*np.pi-state_copy[4]*2*np.pi/360)/396000
    return state_copy
    
# ###########test
# state=[0,0,8.9,800,90]
# import matplotlib.pyplot as plt
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# for i in range(10):
#     state=action(state,1)
#     ax.scatter3D(state[0],state[1],state[2],color='blue',s=8)
# for i in range(10):
#     state=action(state,3)
#     ax.scatter3D(state[0],state[1],state[2],color='yellow',s=8)  
# for i in range(10):
#     state=action(state,2)
#     ax.scatter3D(state[0],state[1],state[2],color='red',s=8)    
# for i in range(10):
#     state=action(state,4)
#     ax.scatter3D(state[0],state[1],state[2],color='green',s=8) 
# for i in range(10):
#     state=action(state,5)
#     ax.scatter3D(state[0],state[1],state[2],color='black',s=8)     
# plt.show()