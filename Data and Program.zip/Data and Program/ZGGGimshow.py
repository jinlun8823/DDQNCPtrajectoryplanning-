import matplotlib.pyplot as plt
from plotZGGG import plotenv

# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib import cm
# from matplotlib.ticker import LinearLocator, FormatStrFormatter
# from matplotlib.ticker import MultipleLocator
# from scipy.interpolate import make_interp_spline
# import numpy as np
# import matplotlib.pyplot as plt
# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=18.5##########五号
# plt.rcParams["text.color"]='black'
# plt.rcParams["mathtext.fontset"]='stix'
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# # ax = fig.gca()
# font = {'family': 'SimSun',
#         'color':  'black',
#         'weight': 'normal',
#         'size': 18.5,
#         }#############x,y,z标签的字体
# z_major_locator=MultipleLocator(0.3)
# #把x轴的刻度间隔设置为1，并存在变量里

# ax.zaxis.set_major_locator(z_major_locator)
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
# ax.xaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
# ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['color'] = "gray"##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
# ax.xaxis._axinfo["grid"]['color'] = "gray"
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
# ax.yaxis._axinfo["grid"]['color'] = "gray"
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"
# ax.set_xlim(111,116)
# ax.set_ylim(22,26)
# ax.set_zlim(9.1,10.4)
# # plt.axes.get_yaxis().set_visible(False)
# # plt.axes.get_xaxis().set_visible(False)
# plt.axis('off')
ax.show()
plotenv()





# cbar=fig.colorbar(surf,shrink=0.7, aspect=15)
# # cbar=fig.colorbar(surf, shrink=0.7, aspect=15)

# cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字










# plt.show()