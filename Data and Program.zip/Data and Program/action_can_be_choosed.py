import numpy as np

#state=[x,y,h,v,d,+-10]

def get_action_space(state):
    if state[2]>=11.01:####高度太高，不能再爬升
        action_can_choosed={1,2,3,5}
    elif state[2]<=8.39:#####高度太低，不能再下降
        action_can_choosed={1,2,3,4}
    elif (8.88<=state[2]<=8.92 or 9.18<=state[2]<=9.22 or 9.48<=state[2]<=9.52 or 9.78<=state[2]<=9.82 or 10.08<=state[2]<=10.12 or 10.38<=state[2]<=10.42 or 10.68<=state[2]<=10.72):#####到达规定高度层
        action_can_choosed={1,2,3,4,5}
    else:########没有到达规定高度层，只能上升或下降
        action_can_choosed={4,5}
    return action_can_choosed
# ########test
# act_space=get_action_space([100,100,8.4,0,0])
