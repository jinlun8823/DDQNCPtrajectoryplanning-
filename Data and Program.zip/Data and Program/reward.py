import numpy as np
# ############################################################算d_reward
# org1=[0,0,9.2]
# org2=[0,100,9.2]
# destination1=[100,100,9.8]
# destination2=[100,0,9.8]

def d_reward1(x1,y1,h1,x1_1s,y1_1s,h1_1s,destination1x,destination1y,destination1h):
    D1=((x1-destination1x)**2+(y1-destination1y)**2)**(1/2)
    D2=((x1_1s-destination1x)**2+(y1_1s-destination1y)**2)**(1/2)
    H1=abs(h1-destination1h)
    H2=abs(h1_1s-destination1h)
    r1=10*(D1-D2)/(D1+0.0000000001)-10
    r2=10*(H1-H2)/(H1+0.000000001)-10
    d1_reward=r1+r2
    return d1_reward

def d_reward2(x2,y2,h2,x2_1s,y2_1s,h2_1s,destination2x,destination2y,destination2h):
    D1=((x2-destination2x)**2+(y2-destination2y)**2)**(1/2)
    D2=((x2_1s-destination2x)**2+(y2_1s-destination2y)**2)**(1/2)
    H1=abs(h2-destination2h)
    H2=abs(h2_1s-destination2h)
    r1=10*(D1-D2)/(D1+0.0000000001)-10
    r2=10*(H1-H2)/(H1+0.000000001)-10
    d2_reward=r1+r2
    return d2_reward
# ######test#######
# dreward1=d_reward1(org1[0],org1[1],org1[2],-50,50,9.8,destination1[0],destination1[1],destination1[2])
# dreward2=d_reward2(org2[0],org2[1],org2[2],50,50,9.2,destination2[0],destination2[1],destination2[2])
#############################################################算f_reward
from fuelcalculation import atpara,CtoT,D,Thrforcr,FUELforcr,angle
from fuelcalculation import Thrforclimb,FUELforclimb,Thrfordecend,FUELfordecend
mref=60;S=124.65;
cf1=0.6864;cf2=952.85;cf3=10.592;cf4=59399;cfcr=0.9342;
cd0cr=0.023738;cd2cr=0.037669;
vclimb=1500;vdecend=3000;#####单位ft/min
def f1_reward(h1,v1,f1s1climbing,f1s1decenting,f1s1straghting):#######算油耗的(h1,v1,是否爬升，是否下降，是否平飞)
    h=h1*1000
    atpara1=atpara(h,0)
    if f1s1climbing==1:
        tas1=CtoT(v1,vclimb,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(v1,vclimb)
        thr1=Thrforclimb(Df,mref,xita)
        fuel1=-1*FUELforclimb(cf1,cf2,tas1,thr1)
    elif f1s1decenting==1:
        tas1=CtoT(v1,vdecend,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(v1,vdecend)
        thr1=Thrfordecend(Df,mref,xita)
        fuel1=-1*FUELfordecend(cf1,cf2,cf3,cf4,h,tas1,thr1)
    else:
        tas1=CtoT(v1,0,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        thr1=Thrforcr(Df)
        fuel1=FUELforcr(cf1,cf2,cfcr,tas1,thr1)
        fuel1=-1*fuel1
    return fuel1

def f2_reward(h2,v2,f2s1climbing,f2s1decenting,f2s1straghting):#######算油耗的(h1,v1,是否爬升，是否下降，是否平飞)
    h=h2*1000
    atpara1=atpara(h,0)
    if f2s1climbing==1:
        tas1=CtoT(v2,vclimb,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(v2,vclimb)
        thr1=Thrforclimb(Df,mref,xita)
        fuel1=-1*FUELforclimb(cf1,cf2,tas1,thr1)
    elif f2s1decenting==1:
        tas1=CtoT(v2,vdecend,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        xita=angle(v2,vdecend)
        thr1=Thrfordecend(Df,mref,xita)
        fuel1=-1*FUELfordecend(cf1,cf2,cf3,cf4,h,tas1,thr1)
    else:
        tas1=CtoT(v2,0,atpara1)
        Df=D(mref,S,tas1,cd0cr,cd2cr,atpara1[2])
        thr1=Thrforcr(Df)
        fuel1=FUELforcr(cf1,cf2,cfcr,tas1,thr1)
        fuel1=-1*fuel1
    return fuel1

    
# # #test#数据格式(高度(m),速度(km/h),是否爬升0-1变量，是否下降0-1变量，是否平飞0-1变量)
# f_reward1=f1_reward(9.2,600,0,0,1)
# f_reward2=f2_reward(9.451,666,0,1,0)
# f_reward3=f1_reward(9.451,666,1,0,0)
# # f_reward=f_reward1+f_reward2
# # #test#
######################################################################算s_reward

def s_reward_current(x1,y1,h1,x2,y2,h2):######STCA告警
    if (1000*abs(h2-h1))<=290:
        if ((x1-x2)**2+(y1-y2)**2)**(1/2)<=18/110:
            s_rewards_c=-2000
        else:
            s_rewards_c=0
    else:
        s_rewards_c=0
    return s_rewards_c

def s_reward_future(x1_10,y1_10,h1_10,x2_10,y2_10,h2_10):######冲突
    if (1000*abs(h2_10-h1_10))<=290:
        if ((x1_10-x2_10)**2+(y1_10-y2_10)**2)**(1/2)<=18/110:
            s_rewards_f=-500
        else:
            s_rewards_f=0
    else:
        s_rewards_f=0
    return s_rewards_f
# ########test#####################
# s_r_c=s_reward_current(10,10,9.2,100,10,9.1)
# s_r_f=s_reward_future(10,10,9.2,10,10,9.1)

################################################################################算t_reward
def t_reward1(x1_c,y1_c,x1_f,y1_f,t_centerx,t_centery,t_radius):######################单位都是km
    if ((x1_c-t_centerx)**2+(y1_c-t_centery)**2)**(1/2)<=t_radius:
        t1_reward1=-2000
    else:
        t1_reward1=0
    if ((x1_f-t_centerx)**2+(y1_f-t_centery)**2)**(1/2)<=t_radius:
        t1_reward2=-500
    else:
        t1_reward2=0
    t1_reward3=0
    t1_reward=min(t1_reward1,t1_reward2,t1_reward3)
    return t1_reward

def t_reward2(x2_c,y2_c,x2_f,y2_f,t_centerx,t_centery,t_radius):
    if ((x2_c-t_centerx)**2+(y2_c-t_centery)**2)**(1/2)<=t_radius:
        t2_reward1=-2000
    else:
        t2_reward1=0
    if ((x2_f-t_centerx)**2+(y2_f-t_centery)**2)**(1/2)<=t_radius:
        t2_reward2=-500
    else:
        t2_reward2=0
    t2_reward3=0
    t2_reward=min(t2_reward1,t2_reward2,t2_reward3)
    return t2_reward

############################test##########################################
# t_r1_c= t_reward1(1,1,6,6,4,4,4)
# t_r2_c= t_reward2(1,1,6,6,4,4,4)





