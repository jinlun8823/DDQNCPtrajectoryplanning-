from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from guidence_policy import Aircraft,decidebyguidence, decidebyguidenceonlyone
from action_can_be_choosed import get_action_space
from state_change import action
from matplotlib.patches import Circle
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=18.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure()
# ax = fig.gca(projection='3d')
ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 18.5,
        }#############x,y,z标签的字体
def is_same_altitude(x,y):
        if abs(x-y)<=0.1:
            issame=1
        else:
            issame=0
        return issame
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
# ax.xaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
# ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['color'] = "gray"##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
# ax.xaxis._axinfo["grid"]['color'] = "gray"
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
# ax.yaxis._axinfo["grid"]['color'] = "gray"
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"
#################################################################################################场景设置
A0=Aircraft(org=[0,1,9.2,600,80],des=[1,0,10.1],name='0',state=[0,1,9.2,600,80],statelis=[])
A1=Aircraft(org=[0.8,1,8.9,700,58],des=[0,0.8,10.1],name='1',state=[0.8,1,8.9,700,58],statelis=[])
A2=Aircraft(org=[1,0.5,9.5,500,250],des=[0,0.5,10.4],name='2',state=[1,0.5,9.5,500,250],statelis=[])
A3=Aircraft(org=[0,0,9.2,1000,20],des=[1,1,10.1],name='3',state=[0,0,9.2,1000,20],statelis=[])
A4=Aircraft(org=[0,0.2,10.7,500,90],des=[0.8,1,10.1],name='4',state=[0,0.2,10.7,500,90],statelis=[])
A5=Aircraft(org=[0.4,1,8.9,500,100],des=[1,0.3,9.8],name='5',state=[0.4,1,8.9,500,100],statelis=[])
A6=Aircraft(org=[0.5,0,9.2,500,350],des=[0.7,1,8.9],name='6',state=[0.5,0,9.2,500,350],statelis=[])
A7=Aircraft(org=[0.2,0,9.2,500,20],des=[0.2,1,9.5],name='7',state=[0.2,0,9.2,500,20],statelis=[])
A8=Aircraft(org=[0.7,0,8.4,760,150],des=[0.7,1,9.2],name='8',state=[0.7,0,8.4,360,150],statelis=[])
A9=Aircraft(org=[1,0,9.8,450,130],des=[0,1,10.7],name='9',state=[1,0,9.8,450,130],statelis=[])
Alis=[A0,A1,A2,A3,A4,A5,A6,A7,A8,A9]
# th_center=[60,50];th_r=20
# ax = fig.gca(projection='3d')
#######################################################################main##################
for i in range(1000):
    nameset={'0','1','2','3','4','5','6','7','8','9'}
    #########1s的小循环
    de_array=np.zeros((10,10))
    acdic={}   
    while nameset != set():
        for i in range(10):
            for j in range(10):
                if (str(i) not in nameset) and (str(j) not in nameset) or i==j:
                    de_array[i,j]=-999
                else:
                    de_array[i,j]=is_same_altitude(Alis[i].state[2],Alis[j].state[2])*((Alis[i].state[0]-Alis[j].state[0])**2+(Alis[i].state[1]-Alis[j].state[1])**2)**(1/2)
                if de_array[i,j]>1:
                    de_array[i,j]=-de_array[i,j]+1000

        pos = np.unravel_index(np.argmax(de_array),de_array.shape)
        
        if (str(pos[0]) in nameset) and (str(pos[1]) in nameset):    
            a=decidebyguidence(Alis[pos[0]].state,Alis[pos[1]].state,Alis[pos[0]].des,Alis[pos[1]].des)
            a1=a//10
            a2=a%10
            Alis[pos[0]].state=action(Alis[pos[0]].state,a1)
            Alis[pos[1]].state=action(Alis[pos[1]].state,a2)
            Alis[pos[0]].statelis.append(Alis[pos[0]].state)
            Alis[pos[1]].statelis.append(Alis[pos[1]].state)
            acdic[Alis[pos[0]].name]=round(a1)
            acdic[Alis[pos[1]].name]=round(a2)
            nameset.remove(Alis[pos[0]].name)
            nameset.remove(Alis[pos[1]].name)
        elif (str(pos[0]) not in nameset) and (str(pos[1]) in nameset):
            a= decidebyguidenceonlyone(Alis[pos[0]].state,Alis[pos[1]].state,flight1action=acdic[Alis[pos[0]].name],des1=Alis[pos[0]].des,des2=Alis[pos[1]].des)
            a2=a%10
            Alis[pos[1]].state=action(Alis[pos[1]].state,a2)
            Alis[pos[1]].statelis.append(Alis[pos[1]].state)
            acdic[Alis[pos[1]].name]=round(a2)
            nameset.remove(Alis[pos[1]].name)
        elif (str(pos[0]) in nameset) and (str(pos[1]) not in nameset):
            a= decidebyguidenceonlyone(Alis[pos[1]].state,Alis[pos[0]].state,flight1action=acdic[Alis[pos[1]].name],des1=Alis[pos[1]].des,des2=Alis[pos[0]].des)
            a2=a%10
            Alis[pos[0]].state=action(Alis[pos[0]].state,a2)
            Alis[pos[0]].statelis.append(Alis[pos[0]].state)
            acdic[Alis[pos[0]].name]=round(a2) 
            nameset.remove(Alis[pos[0]].name)
         

 
x_major_locator=MultipleLocator(30)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(30)
#把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim(-0.2,1.3)
plt.ylim(-0.2,1.3)
ax.set_aspect(1)
# nameset.remove(A9.name)
def plotdata(Aircraf):
    x=[]
    y=[]
    z=[]
    H=[]
    t=[]
    for i in range(1000):
        x.append(Aircraf.statelis[i][0])
        y.append(Aircraf.statelis[i][1])
        z.append(Aircraf.statelis[i][2])
        H.append(Aircraf.statelis[i][4])
        t.append(i)
    return x,y,z,H,t
x0,y0,z0,H0,t0=plotdata(A0)
x1,y1,z1,H1,t1=plotdata(A1)
x2,y2,z2,H2,t2=plotdata(A2)
x3,y3,z3,H3,t3=plotdata(A3)
x4,y4,z4,H4,t4=plotdata(A4)
x5,y5,z5,H5,t5=plotdata(A5)
x6,y6,z6,H6,t6=plotdata(A6)
x7,y7,z7,H7,t7=plotdata(A7)
x8,y8,z8,H8,t8=plotdata(A8)
x9,y9,z9,H9,t9=plotdata(A9)

# #################################################################show()#############################二维

surf=ax.scatter(x1, y1,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x2, y2,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x3, y3,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x4, y4,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x5, y5,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x6, y6,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x7, y7,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x8, y8,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x9, y9,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x0, y0,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)

cbar=fig.colorbar(surf, shrink=0.7, aspect=10)

cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字
plt.tick_params(pad=-0)####################################################################轴值与轴的位置调整
ax.set_xlabel(''+'$\mathrm{'+'Lon/o'+'}$',fontdict=font,size=18.5,labelpad=2)########labelpad调轴字间距
ax.set_ylabel(''+'$\mathrm{'+'Lat/o'+'}$',fontdict=font,size=18.5,labelpad=2)

# ax.set_zlabel('高度'+'$\mathrm{'+'/o'+'}$',fontdict=font,size=18.5,labelpad=2)

################################################################
circle = Circle((0.6, 0.6), radius=0.12, facecolor="royalblue", edgecolor="royalblue")

ax.add_patch(circle)
from matplotlib import pyplot as plt
from matplotlib.path import Path
import numpy as np



# '通过Path类自定义marker'
#定义旋转矩阵
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
    
iconMat = 100*np.array([[0, 9],[1,8],
			[1, 2],
			[7, -3],
			[7, -6],
			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.8],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])

class CustomMarker1(Path):
    def __init__(self, icon, az):
         if icon == "icon": 
             verts = iconMat  
         vertices = rot(verts, az)  
         super().__init__(vertices)


ax.scatter(x0[300], y0[300], marker=CustomMarker1("icon", H0[300]), c="red", s=200)
ax.scatter(x1[370], y1[370], marker=CustomMarker1("icon", H1[370]), c="blue", s=200)
ax.scatter(x2[300], y2[300], marker=CustomMarker1("icon", H2[300]), c="green", s=200)
ax.scatter(x3[370], y3[370], marker=CustomMarker1("icon", H3[370]), c="purple", s=200)
ax.scatter(x4[300], y4[300], marker=CustomMarker1("icon", H4[300]), c="orange", s=200)
ax.scatter(x5[370], y5[370], marker=CustomMarker1("icon", H5[370]), c="yellow", s=200)
ax.scatter(x6[300], y6[300], marker=CustomMarker1("icon", H6[300]), c="black", s=200)
ax.scatter(x7[370], y7[370], marker=CustomMarker1("icon", H7[370]), c="gray", s=200)
ax.scatter(x8[300], y8[300], marker=CustomMarker1("icon", H8[300]), c="deeppink", s=200)
ax.scatter(x9[370], y9[370], marker=CustomMarker1("icon", H9[370]), c="blue", s=200)
plt.show()

# '通过Path类自定义marker'
#定义旋转矩阵
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
    
# iconMat = 100*np.array([[0, 9],[1,8],
#  			[1, 2],
#  			[7, -3],
#  			[7, -6],
#  			[1, -3],
#             [1,-9],
#             [3,-9.5],
#             [3,-10.8],
#             [0.3,-10],
#             [0,-12],
#             [-0.3,-10],[-3,-10.8],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])

# class CustomMarker1(Path):
#     def __init__(self, icon, az):
#           if icon == "icon": 
#               verts = iconMat  
#           vertices = rot(verts, az)  
#           super().__init__(vertices)


# ax.scatter(s1lisx[0], s1lisy[0], marker=CustomMarker1("icon", s1lisd[0]), c="red", s=200)
# ax.scatter(s1lisx[500], s1lisy[500], marker=CustomMarker1("icon", s1lisd[500]), c="red", s=200)
# ax.scatter(s1lisx[200], s1lisy[200], marker=CustomMarker1("icon", s1lisd[200]), c="red", s=200)
# ax.scatter(s1lisx[300], s1lisy[300], marker=CustomMarker1("icon", s1lisd[500]), c="red", s=200)
# ax.scatter(s2lisx[0], s2lisy[0], marker=CustomMarker1("icon", s2lisd[0]), c="green", s=200)
# ax.scatter(s2lisx[500], s2lisy[500], marker=CustomMarker1("icon", s2lisd[500]), c="green", s=200)
# plt.show()

# surf=ax.scatter(t, s1lisz,c=t,cmap=cm.plasma, label='parametric curve',s=1,alpha=0.9)
# plt.show()
#################################################################################三维
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from guidence_policy import Aircraft,decidebyguidence, decidebyguidenceonlyone
from action_can_be_choosed import get_action_space
from state_change import action
from matplotlib.patches import Circle
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=18.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure()
ax = fig.gca(projection='3d')
# ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 18.5,
        }#############x,y,z标签的字体
ax.set_xlim(-0.2,1.3)
ax.set_ylim(-0.2,1.3)
ax.set_zlim(8.6,10.7)
ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
ax.xaxis.set_major_formatter(FormatStrFormatter('%.01f'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.01f'))
ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['color'] = "gray"##############x,y,z网格线颜色
ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
ax.xaxis._axinfo["grid"]['color'] = "gray"
ax.xaxis._axinfo["grid"]['linestyle'] = "-"
ax.yaxis._axinfo["grid"]['color'] = "gray"
ax.yaxis._axinfo["grid"]['linestyle'] = "-"
################################################################################################场景设置
ax.set_xlabel(''+'$\mathrm{'+'Lon/o'+'}$',fontdict=font,size=18.5,labelpad=10)########labelpad调轴字间距
ax.set_ylabel(''+'$\mathrm{'+'Lat/o'+'}$',fontdict=font,size=18.5,labelpad=10)
ax.set_zlabel(''+'$\mathrm{'+'Altitude/km'+'}$',fontdict=font,size=18.5,labelpad=10)
surf=ax.scatter(x1, y1,z1,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x2, y2,z2,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x3, y3,z3,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x4, y4,z4,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x5, y5,z5,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x6, y6,z6,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x7, y7,z7,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x8, y8,z8,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x9, y9,z9,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(x0, y0,z0,c=t0,cmap=cm.gist_ncar, label='parametric curve',s=1,alpha=0.9)   
# ax.scatter(x0[300], y0[300],z0[300], marker=CustomMarker1("icon", H0[300]), c="red", s=200)
# ax.scatter(x1[370], y1[370], z1[370],marker=CustomMarker1("icon", H1[370]), c="blue", s=200)
# ax.scatter(x2[300], y2[300], z2[300],marker=CustomMarker1("icon", H2[300]), c="green", s=200)
# ax.scatter(x3[370], y3[370], z3[370],marker=CustomMarker1("icon", H3[370]), c="purple", s=200)
# ax.scatter(x4[300], y4[300],z4[300], marker=CustomMarker1("icon", H4[300]), c="orange", s=200)
# ax.scatter(x5[370], y5[370], z5[370],marker=CustomMarker1("icon", H5[370]), c="yellow", s=200)
# ax.scatter(x6[300], y6[300],z6[300], marker=CustomMarker1("icon", H6[300]), c="black", s=200)
# ax.scatter(x7[370], y7[370],z7[370], marker=CustomMarker1("icon", H7[370]), c="gray", s=200)
# ax.scatter(x8[300], y8[300],z8[300], marker=CustomMarker1("icon", H8[300]), c="deeppink", s=200)
# ax.scatter(x9[370], y9[370],z9[370], marker=CustomMarker1("icon", H9[370]), c="blue", s=200) 
cbar=fig.colorbar(surf, shrink=0.7, aspect=15)

cbar.set_label(''+'$\mathrm{'+'Time/s'+'}$',size=18,fontdict=font)#####cbar的文字
# plt.tick_params(pad=-0)####################################################################轴值与轴的位置调整
u = np.linspace(0,2*np.pi,50)  # 把圆分按角度为50等分
h = np.linspace(0,3,20)        # 把高度1均分为20份
x = 0.13*np.outer(np.sin(u),np.ones(len(h)))+0.6  # x值重复20次
y = 0.13*np.outer(np.cos(u),np.ones(len(h)))+0.6  # y值重复20次
z = np.outer(np.ones(len(u)),h)+8   # x，y 对应的高度

# Plot the surface
ax.plot_surface(x, y, z, color='skyblue',alpha=0.5)
 
ax.view_init(40,10)
plt.show()

###############################################################