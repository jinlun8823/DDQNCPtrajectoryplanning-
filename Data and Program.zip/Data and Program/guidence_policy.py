import numpy as np
from reward import d_reward1,d_reward2,f1_reward,f2_reward,s_reward_current,s_reward_future,t_reward1, t_reward2
from action_can_be_choosed import get_action_space
from state_change import action
from matplotlib.patches import Circle

th_center=[114.3,23.2];th_r=0.5
##############引导策略，一方面是为了加速执行者网络收敛，另一方面是为了构建评价者网络，再有是危险气候环境下的最保底策略
#state=[x,y,h,v,d]
########程序逻辑：根据state获得action_space,根据total_reward对action进行排序，选择最好的action就可以了，action的空间最大到25(5*5)
######[LRSCD]T.[LRSCD]两架飞机的可选动作空间要翻倍，两个for循环
######[[LL,LR,LS,LC,LD],
#######[RL,RR,RS,RC,RD],
#######[SL,SR,SS,SC,SD],
#######[CL,CR,CS,CC,CD],
#######[DL,DR,DS,DC,DD]]
#####{11:reward,12:reward,...,.}在字典里挑出Reward最大的键就可以了
class Aircraft:######智能体的强化学习建模
    def __init__(self,org,des,name,state,statelis):#######智能体参数
        self.org=org
        self.des=des
        self.name=name
        self.state=state
        self.statelis=statelis

# org1=[30,40,9.2]
# org2=[50,100,8.9]
# destination1=[100,100,10.1]
# destination2=[100,0,10.1]

##################################################################################################两两协同

def decidebyguidence(state1,state2,des1,des2):
    rewardperstep=[]
    actionspace1=get_action_space(state1)
    actionspace2=get_action_space(state2)
    value_dict={}
    for i in actionspace1:
        for j in actionspace2:
            #########################################################################
            state1_1s=action(state1,i)
            state2_1s=action(state2,j)
            d1_reward=d_reward1(state1[0],state1[1],state1[2],state1_1s[0],state1_1s[1],state1_1s[2],des1[0],des1[1],des1[2])
            d2_reward=d_reward2(state1[0],state1[1],state1[2],state2_1s[0],state2_1s[1],state2_1s[2],des2[0],des2[1],des2[2])
            d_reward=d1_reward+d2_reward
            ###########################################################################
            if i==4:
                f1c=1;f1d=0;f1s=0
            elif i==5:
                f1c=0;f1d=1;f1s=0
            else:
                f1c=0;f1d=0;f1s=1
            if j==4:
                f2c=1;f2d=0;f2s=0
            elif j==5:
                f2c=0;f2d=1;f2s=0
            else:
                f2c=0;f2d=0;f2s=1
            f_reward1=f1_reward(state1[2],state1[3],f1c,f1d,f1s)
            f_reward2=f2_reward(state2[2],state2[3],f2c,f2d,f2s)
            f_reward=f_reward1+f_reward2
            ########################################################################
            state1_15s=state1.copy()
            state2_15s=state2.copy()
            for t in range(10):
                state1_15s=action(state1_15s,i)
                state2_15s=action(state2_15s,j)
            s_r_c=s_reward_current(state1_1s[0],state1_1s[1],state1_1s[2],state2_1s[0],state2_1s[1],state2_1s[2])
            s_r_f=s_reward_future(state1_15s[0],state1_15s[1],state1_15s[2],state2_15s[0],state2_15s[1],state2_15s[2])
            s_reward=s_r_c+s_r_f
            # print(s_reward)
            #######################################################################
            t1_reward=t_reward1(state1_1s[0],state1_1s[1],state1_15s[0],state1_15s[1],th_center[0],th_center[1],th_r)
            t2_reward=t_reward2(state2_1s[0],state2_1s[1],state2_15s[0],state2_15s[1],th_center[0],th_center[1],th_r)
            th_reward=t1_reward+t2_reward
            
            value_dict[i*10+j]=d_reward+s_reward+th_reward+0.05*f_reward
    best_action = max(value_dict, key=value_dict.get)
    # print(value_dict[best_action])
    rewardperstep.append(value_dict[best_action])
    return best_action
####################################################################################################单架协同

def decidebyguidenceonlyone(state1,state2,flight1action,des1,des2):
    rewardperstep=[]
    a1=set()
    a1.add(flight1action)
    actionspace1=a1
    actionspace2=get_action_space(state2)
    value_dict={}
    for i in actionspace1:
        for j in actionspace2:
            #########################################################################
            state1_1s=action(state1,i)
            state2_1s=action(state2,j)
            d1_reward=d_reward1(state1[0],state1[1],state1[2],state1_1s[0],state1_1s[1],state1_1s[2],des1[0],des1[1],des1[2])
            d2_reward=d_reward2(state1[0],state1[1],state1[2],state2_1s[0],state2_1s[1],state2_1s[2],des2[0],des2[1],des2[2])
            d_reward=d1_reward+d2_reward
            ###########################################################################
            if i==4:
                f1c=1;f1d=0;f1s=0
            elif i==5:
                f1c=0;f1d=1;f1s=0
            else:
                f1c=0;f1d=0;f1s=1
            if j==4:
                f2c=1;f2d=0;f2s=0
            elif j==5:
                f2c=0;f2d=1;f2s=0
            else:
                f2c=0;f2d=0;f2s=1
            f_reward1=f1_reward(state1[2],state1[3],f1c,f1d,f1s)
            f_reward2=f2_reward(state2[2],state2[3],f2c,f2d,f2s)
            f_reward=f_reward1+f_reward2
            ########################################################################
            state1_15s=state1.copy()
            state2_15s=state2.copy()
            for t in range(10):
                state1_15s=action(state1_15s,i)
                state2_15s=action(state2_15s,j)
            s_r_c=s_reward_current(state1_1s[0],state1_1s[1],state1_1s[2],state2_1s[0],state2_1s[1],state2_1s[2])
            s_r_f=s_reward_future(state1_15s[0],state1_15s[1],state1_15s[2],state2_15s[0],state2_15s[1],state2_15s[2])
            s_reward=s_r_c+s_r_f
            # print(s_reward)
            #######################################################################
            t1_reward=t_reward1(state1_1s[0],state1_1s[1],state1_15s[0],state1_15s[1],th_center[0],th_center[1],th_r)
            t2_reward=t_reward2(state2_1s[0],state2_1s[1],state2_15s[0],state2_15s[1],th_center[0],th_center[1],th_r)
            th_reward=t1_reward+t2_reward
            
            value_dict[i*10+j]=d_reward+s_reward+th_reward+0.05*f_reward
    best_action = max(value_dict, key=value_dict.get)
    # print(value_dict)
    # print(value_dict[best_action])
    rewardperstep.append(value_dict[best_action])
    return best_action


######test
# actiontest= decidebyguidenceonlyone(state1=[30,40,9.2,600,80],state2=[50,100,8.9,700,58],flight1action=1)




