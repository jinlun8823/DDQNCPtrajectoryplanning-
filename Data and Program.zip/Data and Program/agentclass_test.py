from class_agent import DDQNagent
from class_environment import env



agent=DDQNagent(gama=0.95,epsilon=0.35,replayer_capacity=5000)


###神经网络读取测试
agent.evanet.summary()
agent.targetnet.summary()
###神经网络读取测试

#policy获取测试
f1_policy_can=agent.collectpolicy(x=env.f1s[0],y=env.f1s[1],z=env.f1s[2],
                                  vx=env.f1s[3],vy=env.f1s[4],vz=env.f1s[5],
                                  tr=env.f1s[6],tl=env.f1s[7],cl=env.f1s[8],dec=env.f1s[9],straight=env.f1s[10])
print(env.f1s)#(x,y,z,vx,vy,vz,tr,tl,cl,dec,straight)
print(env.f2s)#(x,y,z,vx,vy,vz,tr,tl,cl,dec,straight)
f2_policy_can=agent.collectpolicy(x=env.f2s[0],y=env.f2s[1],z=env.f2s[2],
                                  vx=env.f2s[3],vy=env.f2s[4],vz=env.f2s[5],
                                  tr=env.f2s[6],tl=env.f2s[7],cl=env.f2s[8],dec=env.f2s[9],straight=env.f2s[10])
f3_policy_can=agent.collectpolicy(x=env.f2s[0],y=env.f2s[1],z=env.f2s[2],
                                  vx=env.f2s[3],vy=env.f2s[4],vz=env.f2s[5],
                                  tr=0,tl=0,cl=1,dec=0,straight=0)

#policy获取测试

#生成状态策略对测试
f1_s_a=agent.observation_generator([env.f1s[0],env.f1s[1],env.f1s[2],env.f1s[3],env.f1s[4],env.f1s[5],env.f1s[6],
                                 env.f1s[7],env.f1s[8],env.f1s[9],env.f1s[10]],f1_policy_can)
f2_s_a=agent.observation_generator([env.f2s[0],env.f2s[1],env.f2s[2],env.f2s[3],env.f2s[4],env.f2s[5],env.f2s[6],
                                 env.f2s[7],env.f2s[8],env.f2s[9],env.f2s[10]],f2_policy_can)
#生成状态策略对测试

#挑选最优动作测试(这里有个排列组合要弄)
import numpy as np
a=np.append(f1_s_a[0,:].reshape(1,17),f2_s_a[0,:].reshape(1,17),axis=1)
for j in range(7):
    for i in range(7):
        b=np.append(f1_s_a[j,:].reshape(1,17),f2_s_a[i,:].reshape(1,17),axis=1)
        a=np.append(a,b,axis=0)

s_a=np.append(f1_s_a,f2_s_a,axis=1)
f1_best_action,f2_best_action=agent.choose_best_policy(s_a)#f_best_action=[acc,tr,tl,cl,dc,straight]
# 挑选最优动作测试

# 从经验池挑选经验并学习测试
from replayer import DDQNreplayer5000
observation,action,reward,next_observation,done=DDQNreplayer5000.sample(1)
######################################################################################next_state
f1_next_state=[next_observation[0,0],next_observation[0,1],next_observation[0,2],
                next_observation[0,3],next_observation[0,4],next_observation[0,5],next_observation[0,6],next_observation[0,7],
                next_observation[0,8],next_observation[0,9],next_observation[0,10]]
f2_next_state=[next_observation[0,11],next_observation[0,12],next_observation[0,13],
                next_observation[0,14],next_observation[0,15],next_observation[0,16],next_observation[0,17],next_observation[0,18],
                next_observation[0,19],next_observation[0,20],next_observation[0,21]]
f1_actions_canbeused=agent.collectpolicy(next_observation[0,0],next_observation[0,1],next_observation[0,2],
                  next_observation[0,3],next_observation[0,4],next_observation[0,5],next_observation[0,6],next_observation[0,7],
                  next_observation[0,8],next_observation[0,9],next_observation[0,10])
f2_actions_canbeused=agent.collectpolicy(next_observation[0,11],next_observation[0,12],next_observation[0,13],
                  next_observation[0,14],next_observation[0,15],next_observation[0,16],next_observation[0,17],next_observation[0,18],
                  next_observation[0,19],next_observation[0,20],next_observation[0,21])
f1_stateaction=agent.observation_generator(f1_next_state,f1_actions_canbeused)
f2_stateaction=agent.observation_generator(f2_next_state,f2_actions_canbeused)

ob_ac_pairs=np.append(f1_stateaction,f2_stateaction,axis=1)##############array[s1,a1,s2,a2]的矩阵

f1_best_action,f2_best_action=agent.choose_best_policy(ob_ac_pairs)###########输出了不同航空器的最优策略

f1_next_state=np.reshape(f1_next_state,(1,11))
f2_next_state=np.reshape(f2_next_state,(1,11))##########每个航空器的当前状态

f1_best_action=np.reshape(f1_best_action,(1,6))
f2_best_action=np.reshape(f2_best_action,(1,6))###########################每个航空器当前状态下的最优策略

f1_s_a=np.append(f1_next_state,f1_best_action,axis=1)
f2_s_a=np.append(f2_next_state,f2_best_action,axis=1)

num_input_net=np.append(f1_s_a,f2_s_a,axis=1)########st+1,best at+1

target=reward+agent.gama*agent.targetnet.predict(num_input_net)
##############us=reward+gama*q(st+1,best at+1)
########################################################################################current_state
######################################################################################next_state
f1_current_state=[observation[0,0],observation[0,1],observation[0,2],
              observation[0,3],observation[0,4],observation[0,5],observation[0,6],observation[0,7],
              observation[0,8],observation[0,9],observation[0,10]]
f1_current_state=np.reshape(f1_current_state,(1,11))
f2_current_state=[observation[0,11],observation[0,12],observation[0,13],
                observation[0,14],observation[0,15],observation[0,16],observation[0,17],observation[0,18],
              observation[0,19],observation[0,20],observation[0,21]]
f2_current_state=np.reshape(f2_current_state,(1,11))
f1_action=action[0,0:6]
f1_action=np.reshape(f1_action,(1,6))
f2_action=action[0,6:12]
f2_action=np.reshape(f2_action,(1,6))
f1_s_a=np.append(f1_current_state,f1_action,axis=1)
f2_s_a=np.append(f2_current_state,f2_action,axis=1)
current_s_a=np.append(f1_s_a,f2_s_a,axis=1)
current_s_a[0,0]=current_s_a[0,0]/100;current_s_a[0,1]=current_s_a[0,1]/100;current_s_a[0,2]=current_s_a[0,2]/100
current_s_a[0,3]=current_s_a[0,3]/600;current_s_a[0,4]=current_s_a[0,4]/600; current_s_a[0,5]=current_s_a[0,5]/600
        
current_s_a[0,17]=current_s_a[0,17]/100;current_s_a[0,18]=current_s_a[0,18]/100;current_s_a[0,19]=current_s_a[0,19]/100
current_s_a[0,20]=current_s_a[0,20]/600;current_s_a[0,21]=current_s_a[0,21]/600; current_s_a[0,22]=current_s_a[0,22]/600
        
############################target标准化
target=(target+25000)/900########单步期望-10，2500步期望-10*2500，根据3xigama估算均方差16，16*16*2500开根号等于800，凑个整用900
########################################################
agent.evanet.fit(current_s_a,target,verbose=1)####拟合,训练网络
###agent.evanet.fit(当前的状态策略对，target)
agent.learn_policy_step()






#从经验池挑选经验并学习测试
