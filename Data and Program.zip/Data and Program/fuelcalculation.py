import numpy as np
import pandas as pd

p0=101325;T0=288.15;R=287.05287;ro0=1.225;k=1.4;u=2/7;g0=9.80665

def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A[0]=(A[0]/180)*np.pi
    A[1]=(A[1]/180)*np.pi
    B[0]=(B[0]/180)*np.pi
    B[1]=(B[1]/180)*np.pi
    a=(np.sin((B[1]-A[1])/2))**2
    b=np.cos(A[1])*np.cos(B[1])
    c=(np.sin(B[0]-A[0])/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d

def todictionary(data):#####dic=todictionary(r'D:/adsb/20190529/neidi_20190529/flight.xlsx'),不是CSV
    a=pd.read_excel(data)
    dic={};dictem={}
    for i in range(len(a['fnum'])):
        dictem={a['fnum'][i]:a['r_type'][i]}
        dic.update(dictem)
    return dic

def atpara(height,deltaT=0):######返回一个大气参数列表[T,p,ro],height:m
    if height <=11000:
        T=288.15-0.0065*height
        p=(p0*((T-deltaT)/T0)**-(g0/(-0.0065*R)))
    if height>11000:
        T=288.15-0.0065*11000
        p=(p0*((T-deltaT)/T0)**-(g0/(-0.0065*R)))*(np.e)**(-g0*(height-11000)/(R*T))
    ro=p/(R*T)
    return [T,p,ro]
a=atpara(6000)
def CtoT(speed,vspeed,atpara):########speed:kt,vspeed:ft/min,atpara=[T,p,ro]
    lCAS=speed*1.852/3.6
    vCAS=vspeed/(3.2808*60)
    CAS=(lCAS**2+vCAS**2)**(1/2)
    a=((1+(u/2)*(atpara[2]/atpara[1])*CAS**2)**(1/u))-1
    b=((1+a*(atpara[1]/p0))**u)-1
    TAS=((2/u)*(p0/ro0)*b)**(1/2)
    return TAS##################TAS:m/s

def TAS(speed,vspeed,direct,height,WD=(np.pi)*1.68):########speed:km/h,vspeed:ft/min
    lCAS=speed/3.6
    vCAS=vspeed/(3.2808*60)
    TAS=(lCAS**2+vCAS**2)**(1/2)
    if height<=9000:
        WS=14+((height-6000)/3000)*19
    elif 9000<=height<=11000:
        WS=33
    elif height>=11000:
        WS=30
    aerfa=abs(direct-WD)
    TAS=(TAS**2+WS**2+2*TAS*WS*np.cos(aerfa))**(1/2)
    return TAS

def angle(speed,vspeed):########speed:km/h,vspeed:ft/min
    lCAS=speed/3.6
    vCAS=vspeed/(3.2808*60)
    xita=np.arctan(vCAS/lCAS)
    return xita
def D(mref,Swing,tas,cd0cr,cd2cr,ro):###mref:t,Swing:平方m,TAS:m/s
    mref=mref*1000
    cl=2*mref*g0/(ro*(tas**2)*Swing)
    cd=cd0cr+cd2cr*(cl)**2
    D=(1/2)*ro*(tas**2)*Swing*cd
    return D                   ######匀速时阻力等于推力
def judgecondition(vspeed):
    if vspeed>=300:
        flag='climb'
    elif vspeed<=-300:
        flag='decend'
    else:
        flag='cruise'
    return flag
#############################################################
def Thrforcr(D):
    thr=D######匀速时阻力等于推力
    return thr
def Thrforclimb(D,mref,xita):
    thr=mref*g0*1000*np.sin(xita)+D
    return thr
def Thrfordecend(D,mref,xita):
    thr=D-mref*g0*1000*np.sin(xita)
    return thr
############################################################
def FUELforcr(cf1,cf2,cfcr,tas,thr):#####tas:m/s，但会在函数里变成kt,thr:N,但在函数里变成kN
    ffm=cf1*(1+((tas*3.6/1.852)/cf2))*thr*cfcr/1000##ffm:kg/min
    fuel=ffm/60##ff:kg/s
    return fuel###############FUEL:KG/10s
def FUELforclimb(cf1,cf2,tas,thr):#####tas:m/s但会在函数里变成kt,thr:N,但在函数里变成kN
    ffm=cf1*(1+((tas*3.6/1.852)/cf2))*thr/1000
    fuel=ffm/60
    return fuel
def FUELfordecend(cf1,cf2,cf3,cf4,height,tas,thr):
    ffm1=cf1*(1+((tas*3.6/1.852)/cf2))*thr/1000
    ffm2=cf3*(1-(height/cf4))
    ffm=max(ffm1,ffm2)
    fuel=ffm/60
    return fuel

###测试程序（a320,isa）
#atpara=atpara(11000,0)
#tas=CtoT(715,0,atpara)
#thr=THR(64,122.6,tas,0.026695,0.038726,atpara[2])
#fuel=FUEL(0.75882,2938.5,0.96358,tas,thr)

# #############测试程序（B737,isa）
atpara1=atpara(9451,0)
tas1=CtoT(666,0,atpara1)
D1=D(60,124.65,tas1,0.025452,0.035815,atpara1[2])
thr1=Thrforcr(D1)
fuel=FUELforcr(0.70057,1024.1,0.92958,tas1,thr1)























