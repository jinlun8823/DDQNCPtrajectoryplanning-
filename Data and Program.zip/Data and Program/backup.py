import numpy as np
from reward import d_reward1,d_reward2,f1_reward,f2_reward,s_reward_current,s_reward_future,t_reward1, t_reward2
from action_can_be_choosed import get_action_space
from state_change import action
from matplotlib.patches import Circle
##############引导策略，一方面是为了加速执行者网络收敛，另一方面是为了构建评价者网络，再有是危险气候环境下的最保底策略
#state=[x,y,h,v,d]
########程序逻辑：根据state获得action_space,根据total_reward对action进行排序，选择最好的action就可以了，action的空间最大到25(5*5)
######[LRSCD]T.[LRSCD]两架飞机的可选动作空间要翻倍，两个for循环
######[[LL,LR,LS,LC,LD],
#######[RL,RR,RS,RC,RD],
#######[SL,SR,SS,SC,SD],
#######[CL,CR,CS,CC,CD],
#######[DL,DR,DS,DC,DD]]
#####{11:reward,12:reward,...,.}在字典里挑出Reward最大的键就可以了
class Aircraft:######智能体的强化学习建模
    def __init__(self,org,des,name,state,statelis):#######智能体参数
        self.org=org
        self.des=des
        self.name=name
        ##生成经验池（创建时自带）
        self.state=state
        ##生成评估网络和策略网络（创建时自带）
        self.statelis=statelis
A1=Aircraft(org=[30,40,9.2],des=[100,100,10.1],name='1',state=[30,40,9.2],statelis=[])
A2=Aircraft(org=[50,100,8.9],des=[100,0,10.1],name='2',state=[50,100,8.9],statelis=[])
org1=[30,40,9.2]
org2=[50,100,8.9]
destination1=[100,100,10.1]
destination2=[100,0,10.1]
th_center=[50,70];th_r=20
##################################################################################################两两协同
def decidebyguidence(state1,state2):
    actionspace1=get_action_space(state1)
    actionspace2=get_action_space(state2)
    value_dict={}
    for i in actionspace1:
        for j in actionspace2:
            #########################################################################
            state1_1s=action(state1,i)
            state2_1s=action(state2,j)
            d1_reward=d_reward1(state1[0],state1[1],state1[2],state1_1s[0],state1_1s[1],state1_1s[2],destination1[0],destination1[1],destination1[2])
            d2_reward=d_reward2(state1[0],state1[1],state1[2],state2_1s[0],state2_1s[1],state2_1s[2],destination2[0],destination2[1],destination2[2])
            d_reward=d1_reward+d2_reward
            ###########################################################################
            if i==4:
                f1c=1;f1d=0;f1s=0
            elif i==5:
                f1c=0;f1d=1;f1s=0
            else:
                f1c=0;f1d=0;f1s=1
            if j==4:
                f2c=1;f2d=0;f2s=0
            elif j==5:
                f2c=0;f2d=1;f2s=0
            else:
                f2c=0;f2d=0;f2s=1
            f_reward1=f1_reward(state1[2],state1[3],f1c,f1d,f1s)
            f_reward2=f2_reward(state2[2],state2[3],f2c,f2d,f2s)
            f_reward=f_reward1+f_reward2
            ########################################################################
            state1_15s=state1.copy()
            state2_15s=state2.copy()
            for t in range(10):
                state1_15s=action(state1_15s,i)
                state2_15s=action(state2_15s,j)
            s_r_c=s_reward_current(state1_1s[0],state1_1s[1],state1_1s[2],state2_1s[0],state2_1s[1],state2_1s[2])
            s_r_f=s_reward_future(state1_15s[0],state1_15s[1],state1_15s[2],state2_15s[0],state2_15s[1],state2_15s[2])
            s_reward=s_r_c+s_r_f
            # print(s_reward)
            #######################################################################
            t1_reward=t_reward1(state1_1s[0],state1_1s[1],state1_15s[0],state1_15s[1],th_center[0],th_center[1],th_r)
            t2_reward=t_reward2(state2_1s[0],state2_1s[1],state2_15s[0],state2_15s[1],th_center[0],th_center[1],th_r)
            th_reward=t1_reward+t2_reward
            
            value_dict[i*10+j]=d_reward+s_reward+th_reward+0.05*f_reward
    best_action = max(value_dict, key=value_dict.get)
    print(value_dict[best_action])
    return best_action
####################################################################################################单架协同
def decidebyguidenceonlyone(state1,state2,flight1action):
    a1=set()
    a1.add(flight1action)
    actionspace1=a1
    actionspace2=get_action_space(state2)
    value_dict={}
    for i in actionspace1:
        for j in actionspace2:
            #########################################################################
            state1_1s=action(state1,i)
            state2_1s=action(state2,j)
            d1_reward=d_reward1(state1[0],state1[1],state1[2],state1_1s[0],state1_1s[1],state1_1s[2],destination1[0],destination1[1],destination1[2])
            d2_reward=d_reward2(state1[0],state1[1],state1[2],state2_1s[0],state2_1s[1],state2_1s[2],destination2[0],destination2[1],destination2[2])
            d_reward=d1_reward+d2_reward
            ###########################################################################
            if i==4:
                f1c=1;f1d=0;f1s=0
            elif i==5:
                f1c=0;f1d=1;f1s=0
            else:
                f1c=0;f1d=0;f1s=1
            if j==4:
                f2c=1;f2d=0;f2s=0
            elif j==5:
                f2c=0;f2d=1;f2s=0
            else:
                f2c=0;f2d=0;f2s=1
            f_reward1=f1_reward(state1[2],state1[3],f1c,f1d,f1s)
            f_reward2=f2_reward(state2[2],state2[3],f2c,f2d,f2s)
            f_reward=f_reward1+f_reward2
            ########################################################################
            state1_15s=state1.copy()
            state2_15s=state2.copy()
            for t in range(10):
                state1_15s=action(state1_15s,i)
                state2_15s=action(state2_15s,j)
            s_r_c=s_reward_current(state1_1s[0],state1_1s[1],state1_1s[2],state2_1s[0],state2_1s[1],state2_1s[2])
            s_r_f=s_reward_future(state1_15s[0],state1_15s[1],state1_15s[2],state2_15s[0],state2_15s[1],state2_15s[2])
            s_reward=s_r_c+s_r_f
            # print(s_reward)
            #######################################################################
            t1_reward=t_reward1(state1_1s[0],state1_1s[1],state1_15s[0],state1_15s[1],th_center[0],th_center[1],th_r)
            t2_reward=t_reward2(state2_1s[0],state2_1s[1],state2_15s[0],state2_15s[1],th_center[0],th_center[1],th_r)
            th_reward=t1_reward+t2_reward
            
            value_dict[i*10+j]=d_reward+s_reward+th_reward+0.05*f_reward
    best_action = max(value_dict, key=value_dict.get)
    # print(value_dict)
    print(value_dict[best_action])
    return best_action
######test
# actiontest= decidebyguidenceonlyone(state1=[30,40,9.2,600,80],state2=[50,100,8.9,700,58],flight1action=4)

from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=18.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure()
# ax = fig.gca(projection='3d')
ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 18.5,
        }#############x,y,z标签的字体
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
# ax.xaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.01f'))
# ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
# ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['color'] = "gray"##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
# ax.xaxis._axinfo["grid"]['color'] = "gray"
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
# ax.yaxis._axinfo["grid"]['color'] = "gray"
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"

# ax = fig.gca(projection='3d')
#######################################################################main##################
state1=[30,40,9.2,600,80]
state2=[50,100,8.9,700,58]
s1lisx=[]
s1lisy=[]
s1lisz=[]
s2lisx=[]
s2lisy=[]
s2lisz=[]
s1lisd=[]
s2lisd=[]
t=[]
for i in range(700):
    a=decidebyguidence(state1,state2)
    a1=a//10
    a2=a%10
    state1=action(state1,a1)
    state2=action(state2,a2)
    s1lisx.append(state1[0])
    s1lisy.append(state1[1])
    s1lisz.append(state1[2])
    s2lisx.append(state2[0])
    s2lisy.append(state2[1])
    s2lisz.append(state2[2])
    s1lisd.append(state1[4])
    s2lisd.append(state2[4])
    t.append(i)
#################################################################show()#############################
x_major_locator=MultipleLocator(30)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(30)
#把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim(-10,130)
plt.ylim(-10,130)
ax.set_aspect(1)
surf=ax.scatter(s1lisx, s1lisy,c=t,cmap=cm.plasma, label='parametric curve',s=1,alpha=0.9)
surf=ax.scatter(s2lisx, s2lisy,c=t,cmap=cm.plasma, label='parametric curve',s=1,alpha=0.9)
cbar=fig.colorbar(surf, shrink=0.7, aspect=10)

cbar.set_label('时间'+'$\mathrm{'+'/s'+'}$',size=18,fontdict=font)#####cbar的文字
plt.tick_params(pad=-0)####################################################################轴值与轴的位置调整
ax.set_xlabel('经度'+'$\mathrm{'+'/o'+'}$',fontdict=font,size=18.5,labelpad=2)########labelpad调轴字间距
ax.set_ylabel('纬度'+'$\mathrm{'+'/o'+'}$',fontdict=font,size=18.5,labelpad=2)
# ax.set_zlabel('高度'+'$\mathrm{'+'/o'+'}$',fontdict=font,size=18.5,labelpad=2)
    

# q = np.linspace(0, np.pi * 2, 100)
# s = np.linspace(0, np.pi, 100)

# q, s = np.meshgrid(t, s)
# x = 15*np.cos(q) * np.sin(s)+50
# y = 15*np.sin(q) * np.sin(s)+70
# z = 0.25*np.cos(s)+9.5

# Plot the surface
# ax.plot_surface(x, y, z, color='royalblue')
# ax.view_init(45,5)
# plt.show()

    # print(state2)
################################################################
circle = Circle((50, 70), radius=17, facecolor="royalblue", edgecolor="royalblue")

ax.add_patch(circle)
from matplotlib import pyplot as plt
from matplotlib.path import Path
import numpy as np


# '通过Path类自定义marker'
#定义旋转矩阵
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
    
iconMat = 100*np.array([[0, 9],[1,8],
			[1, 2],
			[7, -3],
			[7, -6],
			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.8],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])

class CustomMarker1(Path):
    def __init__(self, icon, az):
         if icon == "icon": 
             verts = iconMat  
         vertices = rot(verts, az)  
         super().__init__(vertices)


ax.scatter(s1lisx[0], s1lisy[0], marker=CustomMarker1("icon", s1lisd[0]), c="red", s=200)
ax.scatter(s1lisx[500], s1lisy[500], marker=CustomMarker1("icon", s1lisd[500]), c="red", s=200)
ax.scatter(s1lisx[200], s1lisy[200], marker=CustomMarker1("icon", s1lisd[200]), c="red", s=200)
ax.scatter(s1lisx[300], s1lisy[300], marker=CustomMarker1("icon", s1lisd[500]), c="red", s=200)
ax.scatter(s2lisx[0], s2lisy[0], marker=CustomMarker1("icon", s2lisd[0]), c="green", s=200)
ax.scatter(s2lisx[500], s2lisy[500], marker=CustomMarker1("icon", s2lisd[500]), c="green", s=200)
plt.show()

# surf=ax.scatter(t, s1lisz,c=t,cmap=cm.plasma, label='parametric curve',s=1,alpha=0.9)
# plt.show()





